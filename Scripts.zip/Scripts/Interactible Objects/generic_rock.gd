extends Node2D

class_name Rock

@onready var damage_numbers_origin = $DamageNumbersOrigin
@onready var health : int = 30 #rock health
@onready var notDead : bool = true #box is alive
@onready var particle = preload("res://Scenes/Particles/Destruction/rock_purple.tscn")
@onready var player = $"../../Player"

@onready var item: InvItem = get_meta("item")

func _on_ready() -> void:
	$StaticBody2D/collide.set_deferred("disabled", false)
	#print(item.name)

func take_damage(amount: int) -> void: #amount is the damage taken
	#print("Damage: ", amount) #prints the damage taken to the console
	health -= amount
	$"Mining Sounds".playSound()
	if(health > 0): #damage not kills the box
		handle_destruction_particles()
		DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
#item drop animation would go here

	else:
		if(notDead == true):
			handle_destruction_particles()
			DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
			notDead = false
			print(item)
			player.collect(item)
		$PropsCave.visible = false
		$DamageNumbersOrigin.visible = false
		$StaticBody2D/collide.set_deferred("disabled", true)
		#timer so that the final hit sound has time to play
		await get_tree().create_timer(.25).timeout
		self.queue_free()

func handle_destruction_particles() -> void:
	for n in randi_range(1,3):
		var object = particle.instantiate()
		object.position = Vector2(randi_range(-4, 4), randi_range(0, 4) )
		object.scale *= 2
		add_child(object)
