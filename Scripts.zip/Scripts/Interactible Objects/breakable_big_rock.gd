extends Node2D

####################################

#is this script still used?

####################################
@onready var damage_numbers_origin = $DamageNumbersOrigin
@onready var health : int = 30 #rock health
@onready var notDead : bool = true #box is alive
@onready var particle = preload("res://Scenes/Particles/Destruction/rock_purple.tscn")
@onready var player = $"../../Player"

@export var item: InvItem

func _on_ready() -> void:
	$StaticBody2D/collide.set_deferred("disabled", false)
	#print(item.name)

func take_damage(amount: int) -> void: #amount is the damage taken
	#print("Damage: ", amount) #prints the damage taken to the console
	health -= amount
	if(health > 0): #damage not kills the box
		handle_destruction_particles()
		DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
#item drop animation would go here

	else:
		if(notDead == true):
			handle_destruction_particles()
			DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
			notDead = false
			player.collect(item)
		$PropsCave.visible = false
		$DamageNumbersOrigin.visible = false
		$StaticBody2D/collide.set_deferred("disabled", true)
		self.queue_free()

func handle_destruction_particles() -> void:
	for n in randi_range(1,3):
		var object = particle.instantiate()
		object.position = Vector2(randi_range(-4, 4), randi_range(0, 4) )
		object.scale *= 2
		add_child(object)
####################################################################################################
#extends Node2D
#func changeRockColor():
	#if (Globals.currentScene == "res://Scenes/Levels/Mines/minesTheme2.tscn"):
		#$PropsCave.frame = 19
#
#@onready var damage_numbers_origin = $DamageNumbersOrigin
#@onready var health : int = 30 # Rock health
#@onready var notDead : bool = true # Rock is alive
#@onready var particle = preload("res://Scenes/Particles/Destruction/rock_purple.tscn")
#@onready var collide = $StaticBody2D/CollisionShape2D
#
#@export var item: InvItem
#var player: Node = null  # Change from `null` to `Node` type
#
#func _ready() -> void:
	#if collide:
		#collide.set_deferred("disabled", false)
	#else:
		#print_debug("Warning: 'collide' node not found in BreakableBigRock!")
#
#func take_damage(amount: int, attacker: Node = null) -> void:
	#health -= amount
#
	## Store the player reference (only if it's not null)
	#if attacker != null and attacker.is_in_group("player"):  # Check if attacker is the player
		#player = attacker
#
	#if health > 0: # Rock takes damage but doesn't break
		#handle_destruction_particles()
		#DamageNumbers.display_number(amount, damage_numbers_origin.global_position)
	#else:
		#if notDead:
			#handle_destruction_particles()
			#DamageNumbers.display_number(amount, damage_numbers_origin.global_position)
			#notDead = false
#
			## Ensure player exists before trying to call collect
			#if player != null:
				#player.collect(item)
#
		## Hide rock visuals and disable collisions
		#$PropsCave.visible = false
		#$DamageNumbersOrigin.visible = false
		#$StaticBody2D/collide.set_deferred("disabled", true)
		#queue_free()
#
#func handle_destruction_particles() -> void:
	#for n in randi_range(1, 3):
		#var object = particle.instantiate()
		#object.position = Vector2(randi_range(-4, 4), randi_range(0, 4))
		#object.scale *= 2
		#add_child(object)
