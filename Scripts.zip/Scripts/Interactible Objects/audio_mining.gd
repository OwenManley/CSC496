extends Node2D

func playSound():
	$AudioStreamPlayer.play()
