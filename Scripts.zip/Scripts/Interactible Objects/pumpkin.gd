extends Node2D

@onready var damage_numbers_origin = $DamageNumbersOrigin
@onready var health : int = 35 #pumpkin health
@onready var notDead : bool = true #box is alive
@onready var isLarge = $PumpkinSpritesheet.frame_coords.y <= 1 # Check the size by frame coords
@onready var frameOffset : int = int(self.global_position.x + self.global_position.y / 16) % 2
@onready var particle = preload("res://Scenes/Particles/Destruction/pumpkin.tscn")

func _on_ready() -> void:
	#print("IsLarge ", isLarge)
	if(!isLarge):
		frameOffset = abs(int(self.global_position.x + self.global_position.y / 16)) % 4 + 4
	$StaticBody2D/collide.set_deferred("disabled", false)
	$PumpkinSpritesheet.frame_coords.y = frameOffset
	#print("Frame Coords ", frameOffset)

func take_damage(amount: int) -> void: #amount is the damage taken
	#print("Damage: ", amount) #prints the damage taken to the console
	health -= amount
	$"Pumpkin Sounds".playSound()
	if(health > 0): #damage not kills the box
		handle_destruction_particles()
		DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
		if(health > 20):
			$PumpkinSpritesheet.frame = 1
		elif(health > 10):
			$PumpkinSpritesheet.frame = 2
		elif(health > 0):
			$PumpkinSpritesheet.frame = 3
		$PumpkinSpritesheet.frame_coords.y = frameOffset
	else:
		if(notDead == true):
			handle_destruction_particles()
			DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
			notDead = false
		$PumpkinSpritesheet.visible = false
		$DamageNumbersOrigin.visible = false
		$StaticBody2D/collide.set_deferred("disabled", true)
		#timer so that the final hit sound has time to play
		await get_tree().create_timer(.25).timeout
		self.queue_free()
		
func handle_destruction_particles() -> void:
	for n in randi_range(1,3):
		var object = particle.instantiate()
		object.position = Vector2(randi_range(-4, 4), randi_range(0, 4) )
		if(isLarge):
			object.scale *= 2
		add_child(object)
	
