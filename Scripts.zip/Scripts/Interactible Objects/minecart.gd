extends Node2D

var tile_map : TileMapLayer
var tile_coords
@onready var velocity : Vector2 = get_meta("initial_speed")
@onready var push_from : Vector2 = Vector2(0,0)
@onready var is_vertical : bool = false
var pushPower = 10 #CAN NOT BE 0!!!

func _ready() -> void:
	tile_map = get_node("../TileMap Layers/Rails")
	$Sprite2D.frame_coords.y = get_meta("type")

func _process(delta: float) -> void:
	_push()
	if(is_vertical):
		$Sprite2D.frame_coords.x = 1
	else:
		$Sprite2D.frame_coords.x = 0
	
	
	if(tile_map != null):
		tile_coords = tile_map.get_cell_atlas_coords(((self.position) / 16).floor())
				
		# Cart hits bumper.
		if(tile_coords == Vector2i(0,11) || tile_coords == Vector2i(1,11) || tile_coords == Vector2i(0,12)):
			velocity = -velocity * 1.1
		
		if(tile_coords == Vector2i(0,9) || tile_coords == Vector2i(1,10)):
			velocity = Vector2(-velocity.y, -velocity.x)
			$Sprite2D.frame_coords.x = 3
			if(tile_coords == Vector2i(0,9)):
				self.position.y = max(int(self.position.y/16) * 16, self.position.y)
				self.position.x = max(int(self.position.x/16) * 16-12, self.position.x)
			else:
				self.position.y = min(int(self.position.y/16) * 16, self.position.y)
				self.position.x = min(int(self.position.x/16) * 16+12, self.position.x)
				
			
		if(tile_coords == Vector2i(1,9) || tile_coords == Vector2i(0,10)):
			velocity = Vector2(velocity.y, velocity.x)
			$Sprite2D.frame_coords.x = 2
			if(tile_coords == Vector2i(1,9)):
				self.position.y = max(int(self.position.y/16) * 16, self.position.y)
				self.position.x = min(int(self.position.x/16) * 16-4, self.position.x)
			else:
				self.position.y = min(int(self.position.y/16) * 16, self.position.y)
				self.position.x = max(int(self.position.x/16) * 16-12, self.position.x)
				

		# Cart is on horizontal track.
		if(tile_coords == Vector2i(1,13) || tile_coords == Vector2i(2,13) || tile_coords == Vector2i(3,13) ||
			tile_coords == Vector2i(1,14) || tile_coords == Vector2i(2,14) || tile_coords == Vector2i(3,14) ):
			velocity = Vector2(velocity.x, 0)
			self.position.y = int(self.position.y/16) * 16
			is_vertical = false
			
		# Cart is on vertical track.
		if(tile_coords == Vector2i(4,10) || tile_coords == Vector2i(4,11) || tile_coords == Vector2i(4,12) ||
			tile_coords == Vector2i(5,10) || tile_coords == Vector2i(5,11) || tile_coords == Vector2i(5,12) ):
			velocity = Vector2(0, velocity.y)
			self.position.x = int(self.position.x/16) * 16 - 8
			is_vertical = true

		# Cart is on crossed track.
		if(tile_coords == Vector2i(3,11) ):
			if(is_vertical):
				self.position.x = int(self.position.x/16) * 16 - 8
			else:
				self.position.y = int(self.position.y/16) * 16

		self.position.x += velocity.x
		self.position.y += velocity.y
		velocity *= 0.9999
	else:
		print("Level is missing a \"Rails\" tile layer.")
		self.queue_free()

func _push() -> void:
	# Is cart on the cross track?
	if(tile_coords == Vector2i(3,11) ):
		if(is_vertical):
			velocity.y += push_from.y
		else:
			velocity.x += push_from.x
	else:
		velocity += push_from


func _on_area_2d_body_shape_entered(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if(body.get_name() == "Player"):
		push_from = (self.position - body.position)/pushPower
		#print(push_from)
	
func _on_area_2d_body_shape_exited(body_rid: RID, body: Node2D, body_shape_index: int, local_shape_index: int) -> void:
	if(body.get_name() == "Player"):
		push_from = Vector2(0,0)
