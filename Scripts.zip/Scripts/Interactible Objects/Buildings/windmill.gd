extends Node


func _ready() -> void:
	pass # Replace with function body.


func _process(delta: float) -> void:
	$House/Fan.rotate(Globals.windSpeed * 0.01)
