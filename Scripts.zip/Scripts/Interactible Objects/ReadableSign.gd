extends Node2D
class_name ReadableSign

@export var text: Array[String]
@export var isDark: bool
@onready var sign: Array[String]

#@export var frame_coords: Vector2i

func _ready() -> void:
	for i in range(text.size()):
		sign.append("sign" + ("dark" if isDark else "light"))
		text[i] = text[i].replace("\\n", "\n")
	
	if isDark:
		$Sprite2D.texture = load("res://Assets/UI/sign_dark.png")
	
	#$Sprite2D.frame_coords.x = frame_coords.x
	#$Sprite2D.frame_coords.y = frame_coords.y
	
	self.position = Globals.alignToGrid(self.position, true)

func _process(delta: float) -> void:
	$"Sprite2D Notice".visible = !$NoticeRadius.get_overlapping_bodies().filter(func(node: Node): return node.is_in_group("Player")).is_empty()
	
	if Input.is_action_just_pressed("use") && $Cooldown.is_stopped() && !$ReadingRadius.get_overlapping_bodies().filter(func(node: Node): return node.is_in_group("Player")).is_empty():
		$ReadingRadius.get_overlapping_bodies().filter(func(node: Node): return node.is_in_group("Player"))[0].player_hud.displayDialogue(text,sign,sign, 0)
		$Cooldown.start()

func _on_reading_radius_body_entered(body: Node2D) -> void:
	return
	#if body.is_in_group("Player"):
		#body.player_hud.displayDialogue(text,sign,sign, 0)


func _on_timer_timeout() -> void:
	$"Sprite2D Notice".frame = !$"Sprite2D Notice".frame
