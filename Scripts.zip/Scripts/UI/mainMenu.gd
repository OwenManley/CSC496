extends Control
var demo: Node2D = ResourceLoader.load("res://Scenes/Levels/Demos/demo_" + str(randi_range(1,2)) + ".tscn" ).instantiate()
var zoneInTesting = "res://Scenes/Levels/OutsideAreas/testZone.tscn"

@onready var startButton = $MenuButtons/ScaleHandler_Start/Button
var tutorial = "res://Scenes/Levels/OutsideAreas/Tutorial.tscn"
var firstTownArea = "res://Scenes/Levels/OutsideAreas/firstTownArea.tscn"
var save_path = "user://variable.save"
var doesSaveExist : bool
var isControllerPluggedIn : bool = false
#################################################################################################### 
func _on_ready():
	call_deferred("add_child", demo)
	#upon starting game, check if there is a controller plugged in
	var connected_joysticks  = Input.get_connected_joypads()
	if ((connected_joysticks.size() > 0) && !isControllerPluggedIn && !$Settings.visible):
		isControllerPluggedIn = true
		startButton.grab_focus()
		print("ONREADY START BUTTON!")
		print(isControllerPluggedIn)
	#upon starting game, check if there is a save file
	if FileAccess.file_exists(save_path):
		doesSaveExist = true
	else:
		doesSaveExist = false
	doesSaveExistFunc()
	
#################################################################################################### 
func _physics_process(_delta: float) -> void:
	var connected_joysticks = Input.get_connected_joypads()
	#if game has started and then controller gets plugged in
	if ((connected_joysticks.size() > 0) && !isControllerPluggedIn):
		isControllerPluggedIn = true
		startButton.grab_focus()
		#print("START BUTTON!")
		#print(isControllerPluggedIn)
	#if game has started and controller is unplugged
	#need the !settings.visible or else this will run both here and in settings  script
	if((connected_joysticks.size() == 0) && isControllerPluggedIn):
		#print("WATER BUCKET RELEASE")
		#print(isControllerPluggedIn)
		var current_focus_control = get_viewport().gui_get_focus_owner()
		#print(str(current_focus_control))
		if current_focus_control:
			current_focus_control.release_focus()
			isControllerPluggedIn = false
			#print(isControllerPluggedIn)
	_on_button_hovered($MenuButtons/ScaleHandler_Start/Button, _delta)
	_on_button_hovered($MenuButtons/ScaleHandler_Continue/Button, _delta)
	_on_button_hovered($MenuButtons/ScaleHandler_Options/Button, _delta)
	_on_button_hovered($MenuButtons/ScaleHandler_Quit/Button, _delta)
	
	_on_button_hovered($MenuButtons/ScaleHandler_Delete/Button, _delta)
	_on_button_hovered($MenuButtons/ScaleHandler_Verify/Button, _delta)
	
	#if settings is not visible, make the stuff that the settings disappeared visible again
	if(!$Settings.visible):
		$MenuButtons.visible = true
		$Title.visible = true
#################################################################################################### 
func _on_button_hovered(button: Button, _delta: float) -> void:	
	if(button.is_hovered() && !button.icon.resource_path.ends_with("_hovered.png")):
		button.icon = load(button.icon.resource_path.replace(".png", "_hovered.png"))
		start_tween(button, "scale", Vector2.ONE * 1.25, 0.25)
	if(!button.is_hovered() && button.icon.resource_path.ends_with("_hovered.png")):
		button.icon = load(button.icon.resource_path.replace("_hovered", ""))
		start_tween(button, "scale", Vector2.ONE, 0.5)
	if(button.has_focus() && !button.icon.resource_path.ends_with("_hovered.png")):
		button.icon = load(button.icon.resource_path.replace(".png", "_hovered.png"))
		start_tween(button, "scale", Vector2.ONE * 1.25, 0.25)
#################################################################################################### 
func start_tween(object:Object, property:String, final_val:Variant, duration:float) -> void:
	var tween = create_tween()
	tween.tween_property(object, property, final_val, duration)
#################################################################################################### 
func _on_start_button_pressed() -> void:
	Globals.globalReset()
	get_tree().change_scene_to_file(Globals.mapTutorial)
	#################################################################################################### 
func _on_continue_pressed() -> void:
	load_data()
	#################################################################################################### 
func _on_delete_button_pressed() -> void:
	#ask "are you sure?"
	$MenuButtons/ScaleHandler_Delete.visible = false
	$MenuButtons/ScaleHandler_Verify.visible = true
#################################################################################################### 
func _on_verify_button_pressed() -> void:
	#user DOES want to delete their save
	DirAccess.remove_absolute(save_path)
	doesSaveExist = false
	if isControllerPluggedIn:
		$MenuButtons/ScaleHandler_Start/Button.grab_focus()
	doesSaveExistFunc()
#################################################################################################### 
func _on_options_button_pressed() -> void:

	#var connected_joysticks  = Input.get_connected_joypads()
	#if ((connected_joysticks.size() > 0) && !isControllerPluggedIn && !$Settings.visible):
		#print("mmnienrcag")
		#print(isControllerPluggedIn)
		#var current_focus_control = get_viewport().gui_get_focus_owner()
		#print(str(current_focus_control))
		#if current_focus_control:
			#current_focus_control.release_focus()
			#isControllerPluggedIn = false
			#print(isControllerPluggedIn)
	$MenuButtons.visible = false
	$Title.visible = false
	$Settings.visible = true
	#$"MarginContainer/VBoxContainer/Master Volume Slider".grab_focus()
#################################################################################################### 
func _on_quit_button_pressed() -> void:
	get_tree().quit()
#################################################################################################### 
func _on_button_pressed() -> void:
	#testing button
	get_tree().change_scene_to_file(zoneInTesting)
#################################################################################################### 
func load_data():
	if FileAccess.file_exists(save_path):
		var file = FileAccess.open(save_path, FileAccess.READ)
		
		#order of stuff MUST match the order that it is saved in (pause_menu script)
		
		Globals.playerHealth = file.get_var(Globals.playerHealth)
		print(str(Globals.playerHealth))
		
		Globals.playerPositionX = file.get_var(Globals.playerPositionX)
		print(str(Globals.playerPositionX))
		
		Globals.playerPositionY = file.get_var(Globals.playerPositionY)
		print(str(Globals.playerPositionY))
		
		Globals.currentScene = file.get_pascal_string()
		print(str(Globals.currentScene))
		
		Globals.previousScene = file.get_pascal_string()
		print(str(Globals.previousScene))
		
		Globals.hasPlayerVisitedMinesYet = file.get_var(Globals.hasPlayerVisitedMinesYet)
		print(str(Globals.hasPlayerVisitedMinesYet))
		
		Globals.generateFromJSON(file.get_line())
		#Inventory.new().slots = JSON.parse_string(file.get_line())
		
		Globals.playerFriend = file.get_pascal_string()
		
		Globals.storyProgressIntroduction = file.get_var(Globals.storyProgressIntroduction)
		#Globals.visitsToTheMines = file.get_var(Globals.visitsToTheMines)
		#print(str(Globals.visitsToTheMines))
		
		Globals.timeOfDay = file.get_var(Globals.timeOfDay)
		
		get_tree().change_scene_to_file(Globals.currentScene)
	else:
		print("no data saved")
#################################################################################################### 
func doesSaveExistFunc():
	if(doesSaveExist):
		$MenuButtons/ScaleHandler_Continue.visible = true
		$MenuButtons/ScaleHandler_Delete.visible = true
	else:
		$MenuButtons/ScaleHandler_Continue.visible = false
		$MenuButtons/ScaleHandler_Delete.visible = false
		$MenuButtons/ScaleHandler_Verify.visible = false
