extends Control

static var SIGN_TEXT_COLOR: Color = Color.ORANGE.darkened(0.8)
static var NPC_TEXT_COLOR: Color = Color.SILVER.lightened(0.2)

@onready var player = $"../../" # References the parent Player.

signal accepted

func _ready() -> void:
	self.visible = false
	self.position.y = -500

func _process(_delta: float) -> void:
	if self.visible && self.position.y < 224.0:
		self.position.y = (self.position.y-224.0) * 0.9 + 224.0

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("dialogueAccept"):
		accepted.emit()
		
func getFace(character: String, face: String) -> Texture2D:
	return ResourceLoader.load("res://Assets/UI/Dialogue Profiles/" + character + "_" + face + ".png")

func displayDialogue(dialogueText, characters, faces, waitTime: float):
	if waitTime > 0:
		await get_tree().create_timer(waitTime).timeout 
	self.visible = true
	player.isControllable = false
	Engine.time_scale = 0
	for i in range(dialogueText.size()):
		if characters[i].contains("sign"):
			var isDark: bool = characters[i].contains("dark")
			$DialogueBackground.texture = load("res://Assets/UI/dialogue_box_sign_" + ("dark" if isDark else "light") + ".png")
			$DialogueBackground.position.x = 32
			$DialogueLabel.modulate = NPC_TEXT_COLOR if isDark else SIGN_TEXT_COLOR
			$DialogueBackground/Profile.hide()
		else:
			$DialogueBackground.texture = load("res://Assets/UI/dialogue_box.png")
			$DialogueBackground.position.x = 0
			$DialogueBackground/Profile.texture = getFace(characters[i], faces[i])
			$DialogueLabel.modulate = NPC_TEXT_COLOR
			$DialogueBackground/Profile.show()
			
		$DialogueLabel.text = dialogueText[i]
		await accepted 
		# Joe: The switch system is now replaced by 3 string arrays, determining:
		# dialogueText - What is said.
		# characters - Who said it.
		# faces - What is their expression.
	self.visible = false
	self.position.y = -500
	Engine.time_scale = 1
	player.isControllable = true
