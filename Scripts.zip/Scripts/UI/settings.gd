extends Control

var master_volume: int
var music_volume: int
var ambient_volume: int
var isControllerPluggedInSettings : bool = false
@onready var masterVolumeSlider = $"MarginContainer/VBoxContainer/Master Volume Slider"

func _ready():
	$".".visible = false
	#loads saved volume value, is defualt 0 if not previously adjusted
	master_volume = Globals.global_master_volume
	music_volume = Globals.global_music_volume
	ambient_volume = Globals.global_ambient_volume
	#sets value of slider to match volume value
	$"MarginContainer/VBoxContainer/Master Volume Slider".set_value(master_volume)
	$"MarginContainer/VBoxContainer/Music Volume Slider".set_value(music_volume)
	$"MarginContainer/VBoxContainer/Ambient Music Slider".set_value(ambient_volume)

func _physics_process(delta: float) -> void:
	if($".".visible):
		$"MarginContainer/VBoxContainer/Master Volume/Master Volume Label".text = str(master_volume)
		$"MarginContainer/VBoxContainer/Music Volume/Music Volume Label".text = str(music_volume)
		$"MarginContainer/VBoxContainer/Ambient Music/Ambient Music Label".text = str(ambient_volume)
		#if game has started and then controller gets plugged in
		#var connected_joysticks = Input.get_connected_joypads()
		#if ((connected_joysticks.size() > 0) && !isControllerPluggedInSettings):
			#isControllerPluggedInSettings = true
			#masterVolumeSlider.grab_focus()
			#print("master slider")
			#print(isControllerPluggedInSettings)
			#var current_focus_control = get_viewport().gui_get_focus_owner()
			#print(str(current_focus_control))
		##if game has started and controller is unplugged
		#if((connected_joysticks.size() == 0) && isControllerPluggedInSettings):
			#var current_focus_control = get_viewport().gui_get_focus_owner()
			#print(str(current_focus_control))
			#if current_focus_control:
				#current_focus_control.release_focus()
				#isControllerPluggedInSettings = false
				#print(isControllerPluggedInSettings)
		

	#if((connected_joysticks.size() == 0) && isControllerPluggedIn):
		#var current_focus_control = get_viewport().gui_get_focus_owner()
		#if current_focus_control:
			#current_focus_control.release_focus()
			#isControllerPluggedIn = false

func _on_master_volume_slider_value_changed(value: float) -> void:
	AudioServer.set_bus_volume_db(0,value) #the 0 means the Master Bus
	#saves changed volume value to globals
	Globals.global_master_volume = value
	#actually changes volume
	master_volume = Globals.global_master_volume

func _on_music_volume_slider_value_changed(value: float) -> void:
	AudioServer.set_bus_volume_db(1,value) #the 1 means the Music Bus
	#saves changed volume value to globals
	Globals.global_music_volume = value
	#actually changes volume
	music_volume = Globals.global_music_volume

func _on_ambient_music_slider_value_changed(value: float) -> void:
	AudioServer.set_bus_volume_db(2,value) #the 2 means the Ambient Bus
	#saves changed volume value to globals
	Globals.global_ambient_volume = value
	#actually changes volume
	ambient_volume = Globals.global_ambient_volume

func _on_check_box_toggled(toggled_on: bool) -> void:
	AudioServer.set_bus_mute(0, $MarginContainer/VBoxContainer/CheckBox.button_pressed)

func _on_return_to_main_menu_pressed() -> void:
	#var current_focus_control = get_viewport().gui_get_focus_owner()
	#if current_focus_control:
		#current_focus_control.release_focus()
	$".".visible = false

"""
This is what I had before i shoed Joseph and the audio kept being weird
extends Control

var tempVolume : int

func _on_ready() -> void:
	#update the label for the volume slider off rip
	$MarginContainer/VBoxContainer/Volume.value = Globals.volume

func _physics_process(delta: float) -> void:
	#continuously update the label for the volume slider
	$MarginContainer/VBoxContainer/VolumeLabel/Label.text = str(Globals.volume)
	$MarginContainer/VBoxContainer/Volume.value = Globals.volume

func _on_volume_value_changed(value: float) -> void:
	updateVolume()
		AudioServer.set_bus_volume_db(0,value)
	Globals.volume = value
	if $MarginContainer/VBoxContainer/Mute.button_pressed == true:
		$MarginContainer/VBoxContainer/Mute.button_pressed = false

func _on_mute_toggled(toggled_on: bool) -> void:
	print(str(toggled_on))
	if toggled_on:
		print("we on")
		tempVolume = $MarginContainer/VBoxContainer/Volume.value
		print(str(tempVolume))
		AudioServer.set_bus_volume_db(0,0)
		Globals.volume = 0
	#elif !toggled_on:
		#print("not we on")
		##toggled back on
		#Globals.volume = tempVolume

func _on_return_to_main_menu_pressed() -> void:
	Globals.volume
	get_tree().change_scene_to_file("res://Scenes/mainMenu.tscn")

func updateVolume():
	pass
"""
