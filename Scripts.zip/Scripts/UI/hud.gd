extends CanvasLayer

#@onready var levelLabel = $LevelLabels/LevelLabel

func update_level(level):
	#$LevelLabel.visible = true
	$LevelLabel.text = str(level)
	#print("this is yes " + levelLabel.text)

func turn_on_cat():
	var soundy : int = randi() % 100
	print("soundy is: " + str(soundy))
	if(soundy == 20): #1 in 10,000 for a hampter
		$Hampter.visible = true
		$hampter.play()
		await get_tree().create_timer(10).timeout
		$Hampter.visible = false
	else:
		$cat.visible = true
		$sigma.play()
		await get_tree().create_timer(10).timeout
		$cat.visible = false
	

func turn_on_mining():
	$LevelLabels.visible = true
	
	
