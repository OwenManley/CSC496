extends Control

@onready var player = $".."
var save_path = "user://variable.save"
var mainMenu = "res://Scenes/mainMenu.tscn"
var pauseSettings = "res://Scenes/pause_settings.tscn"

func _physics_process(_delta: float) -> void:
	_on_button_hovered($MenuButtons/ScaleHandler_Resume/Button, _delta)
	_on_button_hovered($MenuButtons/ScaleHandler_Save/Button, _delta)
	_on_button_hovered($MenuButtons/ScaleHandler_Options/Button, _delta)
	_on_button_hovered($MenuButtons/ScaleHandler_Quit/Button, _delta)
	
	if(!$Settings.visible): #if settings is not visible, make the stuff that the settings disappeared visible again
		$MenuButtons.visible = true

#################################################################################################### 
func _on_resume_pressed() -> void:
	player.pauseMenu()
#################################################################################################### 
func _on_save_pressed() -> void:
	save()
#################################################################################################### 
func _on_options_pressed() -> void:
	$MenuButtons.visible = false
	$Settings.visible = true
#################################################################################################### 
func _on_main_menu_pressed() -> void:
	print("Quiting to Menu")
	Globals.inventory.clearInventory()
	player.pauseMenu()
	get_tree().change_scene_to_file(mainMenu)
#################################################################################################### 
func save():
	var file = FileAccess.open(save_path, FileAccess.WRITE)
	
	file.store_var(Globals.playerHealth)
	print(str(Globals.playerHealth))
	
	Globals.playerPositionX = player.global_position.x
	file.store_var(Globals.playerPositionX)
	#file.store_var(player.global_position.x)
	print(str(Globals.playerPositionX))
	#print(str(player.global_position.x))
	
	Globals.playerPositionY = player.global_position.y
	file.store_var(Globals.playerPositionY)
	#file.store_var(player.global_position.y)
	print(str(Globals.playerPositionY))
	#print(str(player.global_position.y))
	
	file.store_pascal_string(Globals.currentScene)
	#file.store_var(Globals.currentScene)
	print(str(Globals.currentScene))

	file.store_pascal_string(Globals.previousScene)
	print(str(Globals.previousScene))
	
	file.store_var(Globals.hasPlayerVisitedMinesYet) #get rid of once go through other code
	print(str(Globals.hasPlayerVisitedMinesYet))
	
	file.store_line(Globals.inventory.parseToJSON())
	print(str(Globals.inventory.parseToJSON()))
	
	file.store_pascal_string(Globals.playerFriend)
	print(str(Globals.playerFriend))
	
	file.store_var(Globals.storyProgressIntroduction)
	print(str(Globals.storyProgressIntroduction))
	
	file.store_var(Globals.timeOfDay)
	print(str(Globals.timeOfDay))
#################################################################################################### 
func _on_button_hovered(button: Button, _delta: float) -> void:	
	if(button.is_hovered() && !button.icon.resource_path.ends_with("_hovered.png")):
		button.icon = load(button.icon.resource_path.replace(".png", "_hovered.png"))
		start_tween(button, "scale", Vector2.ONE * 1.25, 0.25)
	if(!button.is_hovered() && button.icon.resource_path.ends_with("_hovered.png")):
		button.icon = load(button.icon.resource_path.replace("_hovered", ""))
		start_tween(button, "scale", Vector2.ONE, 0.5)
	if(button.has_focus() && !button.icon.resource_path.ends_with("_hovered.png")):
		button.icon = load(button.icon.resource_path.replace(".png", "_hovered.png"))
		start_tween(button, "scale", Vector2.ONE * 1.25, 0.25)

func start_tween(object:Object, property:String, final_val:Variant, duration:float) -> void:
	var tween = create_tween()
	tween.tween_property(object, property, final_val, duration)
