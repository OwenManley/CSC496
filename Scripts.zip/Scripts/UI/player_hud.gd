extends CanvasLayer

@onready var healthBar = $HealthBar/Health
@onready var player = $"../" # References the parent Player.

var upToDate: bool = false

func _on_ready() -> void:
	$".".visible = true

func _process(delta: float) -> void:
	if !upToDate:
		upToDate = true
		if get_tree().current_scene.scene_file_path.contains("Outside"):
			if Globals.timeOfDay < 0.2 || Globals.timeOfDay > 0.8:
				$Filters/Shader.environment = Globals.shaderNight
				$Filters/Night.visible = true
			else:
				$Filters/Shader.environment = null
				$Filters/Night.visible = false


func update_level(level: int):
	$CaveLevel.visible = level > -1
	$CaveLevel/CounterLabel.text = str(level)

func update_health(playerHealth, maxHealth, shouldFlash: bool): 
	# Joe: I assume these are pass by value, not by reference.
	$HealthBar/HealthLabel.text = str(playerHealth)
	if(playerHealth > maxHealth):
		playerHealth = maxHealth
	if(playerHealth < 0):
		playerHealth = 0
		
		
	if(shouldFlash):
		for sub in 4:
			healthBar.frame = 20
			await get_tree().create_timer(0.14).timeout # Joe: Value is in seconds.
			healthBar.frame = (int)(playerHealth - 1)
			await get_tree().create_timer(0.14).timeout # Joe: Value is in seconds.
	else:
		healthBar.frame = (int)(playerHealth - 1)

	if(((playerHealth / maxHealth) * 100) <= 10):
		healthBar.frame = 1
	elif(((playerHealth / maxHealth) * 100) <= 20):
		healthBar.frame = 3
		#print("red")
		$HealthBar/HealthLabel.add_theme_color_override("font_color", Color(255, 0, 0))
	elif(((playerHealth / maxHealth) * 100) <= 30):
		healthBar.frame = 5
	elif(((playerHealth / maxHealth) * 100) <= 40):
		healthBar.frame = 7
	elif(((playerHealth / maxHealth) * 100) <= 50):
		healthBar.frame = 9
		#print("orange")
		$HealthBar/HealthLabel.add_theme_color_override("font_color", Color(1, 0.416, 0))
	elif(((playerHealth / maxHealth) * 100) <= 60):
		healthBar.frame = 11
	elif(((playerHealth / maxHealth) * 100) <= 70):
		healthBar.frame = 13
		#print("yellow")
		$HealthBar/HealthLabel.add_theme_color_override("font_color", Color(1, 1, 0))
	elif(((playerHealth / maxHealth) * 100) <= 80):
		healthBar.frame = 15
	elif(((playerHealth / maxHealth) * 100) <= 90):
		healthBar.frame = 17
	elif(((playerHealth / maxHealth) * 100) <= 100):
		#print("green")
		$HealthBar/HealthLabel.add_theme_color_override("font_color", Color(0, 0.761, 0.09))

func displayDialogue(dialogueText, characters, faces, waitTime: float) -> void:
	$Dialogue.displayDialogue(dialogueText, characters, faces, waitTime)

func fadeScreen(_duration: float = 0.25, _startColor: Color = Color.BLACK, _endColor: Color = Color.BLACK) -> void:
	_startColor.a = 0
	$Filters/White.visible = true
	$Filters/White.color = _startColor
	create_tween().tween_property($Filters/White, "color", _endColor, _duration).set_trans(Tween.TRANS_EXPO)
	await get_tree().create_timer(_duration *2).timeout
	create_tween().tween_property($Filters/White, "color", _startColor, _duration).set_trans(Tween.TRANS_EXPO)
	await get_tree().create_timer(_duration *2).timeout
	$Filters/White.visible = false
