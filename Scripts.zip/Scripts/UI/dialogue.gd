extends Node2D

@onready var player = $"../" #reference to the player, which is what this scene should be parented under

signal accepted

func _input(event: InputEvent) -> void:
	if event.is_action_pressed("dialogueAccept"):
		accepted.emit()

func displayDialogue(arrIndexToStartAt: int, arrIndexToEndAtPlusOne: int, waitTime: float):
	#To use, type $Player/Dialogue.displayDialogue(whatToStart, whereToEndPlusOne, howLongUntilDialogueDisplays)
	await get_tree().create_timer(waitTime).timeout 
	self.visible = true
	player.speed = 0
	Engine.time_scale = 0
	for i in range(arrIndexToStartAt, arrIndexToEndAtPlusOne):
		match i:
			0:
				$TextureRect.texture = ResourceLoader.load("res://Assets/temporaryAssets/bridge.png")
				$DialogueLabel.text = "I wonder where everyone went?"
			1:
				$DialogueLabel.text = "The mines used to be quite busy back in the day,"
			2:
				$DialogueLabel.text = "Maybe I should check them out"
			3:
				$DialogueLabel.text = "poggers"
			4:
				$DialogueLabel.text = "poopy butt"
			5:
				$DialogueLabel.text = "That was scary!"
			6:
				$DialogueLabel.text = "Maybe I should try returning back to Ironhaven,"
			7:
				$DialogueLabel.text = "Ah, Ironhaven"
			8:
				$DialogueLabel.text = "The town of my youth,"
			9:
				$DialogueLabel.text = "I should go leave, it's getting spooky"
		await accepted
	self.visible = false
	Engine.time_scale = 1
	player.normalSpeedFunc()
	
	
	#unused, old way of dialogue
	#var dialogueArray = [
	#"I wonder where everyone went", 
	#"The mines used to be quite the bussy back in the day,",
	#"Maybe I should check them out", 
	#"poggers",
	#"poopy butt",
	#"That was scary!",
	#"Maybe I should try returning back to Ironhaven,",
	#"Ah, Ironhaven",
	#"The town of my youth,",
	#]
	
	#await get_tree().create_timer(waitTime).timeout 
	#self.visible = true
	#player.speed = 0
	#Engine.time_scale = 0
	#for i in range(arrIndexToStartAt, arrIndexToEndAtPlusOne):
		#$DialogueLabel.text = dialogueArray[i]
		#await accepted
	#self.visible = false
	#Engine.time_scale = 1
	#player.normalSpeedFunc()
