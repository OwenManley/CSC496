extends Node2D

@onready var damage_numbers_origin = $DamageNumbersOrigin
@onready var SkeletonHealth : int = 30 #30
@onready var notDead : bool = true #skeleton is alive

func take_damage(amount: int) -> void: #amount is the damage taken
	#print("Damage: ", amount) #prints the damage taken to the console
	SkeletonHealth -= amount
	if(SkeletonHealth > 0): #damage kills the box
		DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
		if (SkeletonHealth < 25):
			$Health3.visible = false
		if (SkeletonHealth < 15):
			$Health2.visible = false
	else: #damage is kil
		if(notDead == true):
			DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
			notDead = false
			$"Skeleton Area2D/SkeletonAnimationPlayer".play("SkeletonDies") #wont work, idk why???? #also this sprite is ONLY the skeleton, not the whole spritesheet
		#$"Skeleton Area2D/SkeletonSpritesheet".visible = false
		$"Skeleton Area2D/SkeletonSpritesheet/enemyHitBox/CollisionShape2D".set_deferred("disabled", true)
		$DamageNumbersOrigin.visible = false
		$"Skeleton Area2D/CollisionShape2D".set_deferred("disabled", true)
		$Health1.visible = false

#func _on_skeleton_area_2d_body_entered(body: Node2D) -> void:
	#if (body.is_in_group("Player") && notDead == true):
		###get_tree().change_scene_to_file("res://Scenes/death_scene.tscn")
		##get_tree().reload_current_scene() #when collison body of enemy touches collision body of player, game restarts
		#print("skeleton entered")
		#
	##pass # Replace with function body.
