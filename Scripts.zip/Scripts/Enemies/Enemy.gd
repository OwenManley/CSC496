extends AbstractNPC
class_name Enemy

#################################################################################################### 
enum Mode {
	IDLE,
	WANDER_TO_POINT,
	ATTACK_TARGET
}
var currentMode : Mode = Mode.IDLE

func _ready() -> void:
	super._ready()
	tick.connect(enemyTick)
	$Navigation/Timer.timeout.connect(setTargetPosition)

func _process(delta: float) -> void:
	super._process(delta)
	currentMode = Mode.IDLE if distance > 200 else Mode.ATTACK_TARGET
	
	var shouldRun: bool = currentMode == Mode.ATTACK_TARGET
	
	if currentMode != Mode.IDLE:
		if shouldUseNavigator:
			var nextPathPoint: Vector2 = navigation.get_next_path_position() - global_position
			if nextPathPoint.x > -16:
				moveInDirection(delta, "right", shouldRun)
			if nextPathPoint.x < 16:
				moveInDirection(delta, "left", shouldRun)
			
			if nextPathPoint.y > -16:
				moveInDirection(delta, "down", shouldRun)
			if nextPathPoint.y < 16:
				moveInDirection(delta, "up", shouldRun)
		else:
			if player.position.x-16 > self.position.x:
				moveInDirection(delta, "right", shouldRun)
			if player.position.x+16 < self.position.x:
				moveInDirection(delta, "left", shouldRun)
			
			if player.position.y-16 > self.position.y:
				moveInDirection(delta, "down", shouldRun)
			if player.position.y+16 < self.position.y:
				moveInDirection(delta, "up", shouldRun)
	
	if abs(velocity.x) < 5 && abs(velocity.y) < 5:
		velocity.x = 0
		velocity.y = 0
	else:
		velocity.x = min(abs(velocity.x), abs(velocity.x * 0.75)) * sign(velocity.x)    #without these, we add the veolcity every frame
		velocity.y = min(abs(velocity.y), abs(velocity.y * 0.75)) * sign(velocity.y)    #these lines basically act as friction
	
	move_and_slide()

#################################################################################################### 
func enemyTick() -> void:
	if randf() < 0.01 && currentMode != Mode.ATTACK_TARGET:
		currentMode = Mode.IDLE if currentMode == Mode.WANDER_TO_POINT else Mode.WANDER_TO_POINT

func setTargetPosition() -> void:
	navigation.target_position = player.global_position if currentMode == Mode.ATTACK_TARGET else self.global_position + Vector2(randi_range(-64, 64), randi_range(-64, 64))
