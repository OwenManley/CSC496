extends CharacterBody2D
class_name EnemyBeta

@onready var player: CharacterBody2D = $"../../Player"
@onready var navigation: NavigationAgent2D = $Navigation/NavigationAgent2D
@onready var shouldUseNavigator = true
@onready var hasCollision = true


const REAL_SPEED : int = 850
const SUPER_SPEED : int = 5_000
const MAX_HEALTH : float = 20

@onready var speed : int = REAL_SPEED # Joe: NEVER set to 0, use the isControllable boolean instead.
#################################################################################################### 

@onready var boxy = $TheKnight/myHitbox/hitbox #the sword hitbox
@onready var miny = $TheKnight/myAttackRock/RockAttack #the mining hitbox
@onready var damage_numbers_origin = $DamageNumbersOrigin #where the damage numbers pop out of the player
#################################################################################################### 
var isAttacking : bool = false #is the player attacking?
var isMining : bool = false #is the player minig?
var isControllable : bool = true # Joe: Can the player move?
var sprintMultiplier : int = 4
var EnemyHealth = 30

func _ready() -> void:
	$CollisionShape2D.set_deferred("disabled", !hasCollision)

func _process(delta: float) -> void:
	var dist: float = player.global_position.distance_to(self.global_position)
	var shouldRun: bool = Input.is_action_pressed("run") || dist > 350
	var shouldStop: bool = dist > 500
	if hasCollision:
		$CollisionShape2D.set_deferred("disabled", dist > 350)
	#shouldStop = false
	if !shouldStop:
		
		if shouldUseNavigator:
			var nextPathPoint: Vector2 = navigation.get_next_path_position() - global_position
			if nextPathPoint.x > -16:
				moveInDirection(delta, "right", shouldRun)
			if nextPathPoint.x < 16:
				moveInDirection(delta, "left", shouldRun)
			
			if nextPathPoint.y > -16:
				moveInDirection(delta, "down", shouldRun)
			if nextPathPoint.y < 16:
				moveInDirection(delta, "up", shouldRun)
		else:
			if player.position.x-16 > self.position.x:
				moveInDirection(delta, "right", shouldRun)
			if player.position.x+16 < self.position.x:
				moveInDirection(delta, "left", shouldRun)
			
			if player.position.y-16 > self.position.y:
				moveInDirection(delta, "down", shouldRun)
			if player.position.y+16 < self.position.y:
				moveInDirection(delta, "up", shouldRun)
	
	if abs(velocity.x) < 5 && abs(velocity.y) < 5:
		velocity.x = 0
		velocity.y = 0
	else:
		velocity.x = min(abs(velocity.x), abs(velocity.x * 0.75)) * sign(velocity.x)    #without these, we add the veolcity every frame
		velocity.y = min(abs(velocity.y), abs(velocity.y * 0.75)) * sign(velocity.y)    #these lines basically act as friction
	
	#if velocity.x == 0 && velocity.y == 0 && (
		#animation.current_animation.contains("Walking") || animation.current_animation.contains("Running")):
		#animation.play("Idle")

	move_and_slide()

####################################################################################################
func moveInDirection(delta: float, direction: String, running: bool) -> void:
	var velocityModifier = speed * delta
	if running:
		velocityModifier *= sprintMultiplier
		#animation.play("Running")
	#else:
		#animation.play("Walking")

	if direction.contains("right"):
		velocity.x += velocityModifier
		$AnimatedSprite2D.scale.x = 1
	if direction.contains("left"):
		velocity.x -= velocityModifier
		$AnimatedSprite2D.scale.x = -1
	if direction.contains("up"):
		velocity.y -= velocityModifier
	if direction.contains("down"):
		velocity.y += velocityModifier

func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	var words : PackedStringArray = anim_name.split(' ')
	#if(words[0].contains("Attack") || words[0].contains("Running") || words[0].contains("Walking") || words[0].contains("Hurt")):
		#animation.play("Idle")


func _on_my_hitbox_area_entered(area: Area2D) -> void:
	pass # Replace with function body.


func _on_my_hitbox_body_entered(body: Node2D) -> void:
	pass # Replace with function body.

func _on_timer_timeout() -> void:
	navigation.target_position = player.global_position

#func stop():
	#speed = 0
	
#func take_damage(amount: int) -> void: #amount is the damage taken
	##print("Damage: ", amount) #prints the damage taken to the console
	#$DamageNoises.play()
	#speed = 0
	#EnemyHealth -= amount
	#if(EnemyHealth > 0): #damage kills the box
		#DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
		##make so no takey damage here
		#$myHurtbox/CollisionShape2D.set_deferred("disabled", true)
		#await get_tree().create_timer(.5).timeout
		#await get_tree().create_timer(.5).timeout
		#$myHurtbox/CollisionShape2D.set_deferred("disabled", false)
	#else: #damage is kil
		#if(notDead == true):
			#DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
			#notDead = false
		#animated_sprite_2d.play("dies") #wont work, idk why???? #also this sprite is ONLY the skeleton, not the whole spritesheet
		#$DamageNumbersOrigin.visible = false
		#$myHurtbox/CollisionShape2D.set_deferred("disabled", true)
		#$enemyHitBox/CollisionShape2D.set_deferred("disabled", true)
		#$CollisionShape2D.set_deferred("disabled", true)
		#$Area2D/CollisionPolygon2D.set_deferred("disabled", true)
		#$RayCast2D.enabled = false
