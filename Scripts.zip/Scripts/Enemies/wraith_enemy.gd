extends Node2D

@onready var animation_player := $"Wraith Area2D/WraithAnimationPlayer"

@onready var damage_numbers_origin = $DamageNumbersOrigin
@onready var WraithHealth : int = 50 #50
@onready var notDead : bool = true #wraith is alive

func take_damage(amount: int) -> void: #amount is the damage taken
	#print("Damage: ", amount) #prints the damage taken to the console
	WraithHealth -= amount
	if(WraithHealth > 0): #damage not kill
		DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
	else: #damage is kill
		if(notDead == true):
			DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
			notDead = false
			$"Wraith Area2D/WraithAnimationPlayer".play("WraithDies") #wont work, idk why????
		#$"Wraith Area2D/WraithSpritesheet".visible = false
		$"Wraith Area2D/WraithSpritesheet/enemyHitBox/CollisionShape2D".set_deferred("disabled", true)
		$DamageNumbersOrigin.visible = false
		$"Wraith Area2D/CollisionShape2D".set_deferred("disabled", true)
		
		
#func _on_wraith_area_2d_body_entered(body: Node2D) -> void:
	#if (body.is_in_group("Player") && notDead == true):
		###get_tree().change_scene_to_file("res://Scenes/death_scene.tscn")
		##get_tree().reload_current_scene() #when collison body of enemy touches collision body of player, game restarts
		#print("wraith entered")
	##pass # Replace with function body.
