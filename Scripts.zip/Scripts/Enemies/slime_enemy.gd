extends CharacterBody2D

@export var patrol_points : Node
@export var speed : int = 1_500
@export var wait_time : int = 3

@onready var animated_sprite_2d = $AnimatedSprite2D
@onready var timer = $Timer

enum State {Idle, Walk}
var current_state : State
var direction : Vector2 = Vector2.RIGHT #enemy moves RIGHT until it falls off the edge
var number_of_points : int
var point_positions : Array[Vector2]
var current_point : Vector2
var current_point_position : int
var can_walk : bool

func _ready():
	if patrol_points != null:
		number_of_points = patrol_points.get_children().size()
		for point in patrol_points.get_children():
			point_positions.append(point.global_position)
		current_point = point_positions[current_point_position]
	else:
		print("No patrol points")
	
	timer.wait_time = wait_time
	current_state = State.Idle

func _physics_process(delta: float) -> void:
	enemy_idle(delta)
	enemy_walk(delta)
	
	move_and_slide()
	
	enemy_animations()

func enemy_idle(delta: float) -> void:
	if !can_walk:
		velocity.x = move_toward(velocity.x, 0, speed * delta)
		#velocity.y = move_toward(velocity.y, 0, speed * delta)
		current_state = State.Idle

func enemy_walk(delta: float):
	if !can_walk:
		return
	
	if abs(position.x - current_point.x) > 0.5:
		velocity.x = direction.x * speed * delta
		#velocity.y = direction.y * speed * delta
		current_state = State.Walk
	else:
		current_point_position += 1

		if current_point_position >= number_of_points:
			current_point_position = 0

		current_point = point_positions[current_point_position]

		if current_point.x < position.x:
			direction = Vector2.LEFT
		else:
			direction = Vector2.RIGHT
		can_walk = false
		timer.start()

	animated_sprite_2d.flip_h = direction.x < 0

func enemy_animations():
	if current_state == State.Idle && !can_walk:
		animated_sprite_2d.play("idle")
	elif current_state == State.Walk && can_walk:
		animated_sprite_2d.play("walk")

func _on_timer_timeout() -> void:
	can_walk = true
