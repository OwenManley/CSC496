extends EnemyBeta
#class_name Skeleton

#@export var skeleton : CharacterBody2D
#@export var speed : int = 150

@onready var animated_sprite_2d = $AnimatedSprite2D
#@onready var damage_numbers_origin = $DamageNumbersOrigin
@onready var SkeletonHealth : int = 30 #30
@onready var notDead : bool = true #skeleton is alive

#@onready var navigation: NavigationAgent2D = $Navigation/NavigationAgent2D
#var direction : Vector2 = Vector2.RIGHT
#var current_point : Vector2
var boo : bool = false #player not there
#var rayX
#var rayY

#enum State {Idle, Walk}
#var current_state : State
#var direction : Vector2 = Vector2.RIGHT #enemy moves RIGHT until it falls off the edge
#var number_of_points : int
#var point_positions : Array[Vector2]
#var current_point : Vector2
#var current_point_position : int
#var can_walk : bool

func _ready():
	pass

#func _physics_process(delta: float) -> void:
	##velocity.x = 0
	##velocity.y = 0
	##enemy_idle(delta)
	##enemy_walk(delta)
	#if (boo == true && notDead == true): #player is within the "vision area" and the enemy is not dead
		#
		##makes the raycast arrow follow the player precisely
		#rayX = player.global_position.x - self.global_position.x
		#rayY = player.global_position.y - self.global_position.y
		#$RayCast2D.target_position = Vector2(rayX, rayY)
#
		#$Area2D.look_at(player.global_position)
		#
		#
		#
		#if ($RayCast2D.is_colliding()):
			#var collider = $RayCast2D.get_collider()
			#if (collider == player):
				##move the enemy to the player
				#var moveX = player.global_position.x 
				#var moveY = player.global_position.y
				##global_position = global_position.move_toward(Vector2(moveX, moveY), speed * delta)
				#if(global_position == Vector2(moveX, moveY)):
					#print("ehre")
				
			



		#var skeleX : float = skeleton.global_position.x
		#var playerX : float = player.global_position.x
		#var skeleY :float = skeleton.global_position.y
		#var playerY :float = player.global_position.y
		#print("skeleX: " + str(skeleX) + " + " + "playerX: " + str(playerX))
		#print("skeleY: " + str(skeleY) + " + " + "playerY: " + str(playerY))
		#velocity.x = move_toward(skeleX, playerX, delta)
		#print(velocity.x)
		#velocity.y = move_toward(skeleY, playerY, delta)
		#print(velocity.y)
		
		#var skeleX : float = skeleton.global_position.x
		#var playerX : float = player.global_position.x
		#var skeleY :float = skeleton.global_position.y
		#var playerY :float = player.global_position.y
		#print(global_position.x)
		#if(((playerX - skeleX) > 0) && ((playerY - skeleY) > 0)): #positive number, so positive delta
			#velocity.x = move_toward(skeleX, playerX, delta)
			#velocity.y = move_toward(skeleY, playerY, delta)
		#elif(((playerX - skeleX) < 0) && ((playerY - skeleY) > 0)): #negative x
			#velocity.x = move_toward(skeleX, playerX, -delta)
			#velocity.y = move_toward(skeleY, playerY, delta)
		#elif(((playerX - skeleX) > 0) && ((playerY - skeleY) < 0)): #negative y
			#velocity.x = move_toward(skeleX, playerX, delta)
			#velocity.y = move_toward(skeleY, playerY, -delta)
		#elif(((playerX - skeleX) < 0) && ((playerY - skeleY) < 0)): #negative x & y
			#velocity.x = move_toward(skeleX, playerX, -delta)
			#velocity.y = move_toward(skeleY, playerY, -delta)
		
	#move_and_slide()

func take_damage(amount: int) -> void: #amount is the damage taken
	#print("Damage: ", amount) #prints the damage taken to the console
	$DamageNoises.play()
	speed = 0
	SkeletonHealth -= amount
	if(SkeletonHealth > 0): #damage kills the box
		DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
		#make so no takey damage here
		$myHurtbox/CollisionShape2D.set_deferred("disabled", true)
		await get_tree().create_timer(1.5).timeout
		$myHurtbox/CollisionShape2D.set_deferred("disabled", false)
		speed = REAL_SPEED
	else: #damage is kil
		if(notDead == true):
			DamageNumbers.display_number(amount, damage_numbers_origin.global_position) #, is_critical
			notDead = false
		animated_sprite_2d.play("dies") #wont work, idk why???? #also this sprite is ONLY the skeleton, not the whole spritesheet
		$DamageNumbersOrigin.visible = false
		$myHurtbox/CollisionShape2D.set_deferred("disabled", true)
		$enemyHitBox/CollisionShape2D.set_deferred("disabled", true)
		hasCollision = false
		$CollisionShape2D.set_deferred("disabled", true)
		$Area2D/CollisionPolygon2D.set_deferred("disabled", true)
		$RayCast2D.enabled = false


#func look_for_player():
	#if($Node2D/RayCast2D.is_colliding()):
		#var collider = $Node2D/RayCast2D.get_collider()
		#if collider == player:
			##chase_player()
			#print("chasing")

func _on_area_2d_body_entered(body: Node2D) -> void:
	if (body.is_in_group("Player") && notDead == true):
		print("body entered")
		#boo = true

func _on_area_2d_body_exited(body: Node2D) -> void:
	if (body.is_in_group("Player") && notDead == true):
		print("body leaves (like from trees)")
		#boo = false

#THIS IS STUFF COPIED DIRECTLY FROM THE SLIME
#THIS STUFF WILL WORK WITH SPAWNED SKELEES IF THE PLAYER ENTERS THEIR VISION EARLY ENOUGH
#OTHERWISE CRASHES
#
#func enemy_idle(delta: float) -> void:
	#if !can_walk:
		#velocity.x = move_toward(velocity.x, 0, speed * delta)
		##velocity.y = move_toward(velocity.y, 0, speed * delta)
		#current_state = State.Idle
#
#func enemy_walk(delta: float):
	#if !can_walk:
		#return
	#
	#if abs(position.x - current_point.x) > 0.5:
		#velocity.x = direction.x * speed * delta
		##velocity.y = direction.y * speed * delta
		#current_state = State.Walk
	#else:
		#current_point_position += 1
#
		#if current_point_position >= number_of_points:
			#current_point_position = 0
#
		#current_point = point_positions[current_point_position]
#
		#if current_point.x < position.x:
			#direction = Vector2.LEFT
		#else:
			#direction = Vector2.RIGHT
		#can_walk = false
		#timer.start()
#
	#animated_sprite_2d.flip_h = direction.x < 0
#
