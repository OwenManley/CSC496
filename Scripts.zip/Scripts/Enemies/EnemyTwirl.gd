extends Enemy
class_name EnemyTwirl


func _ready() -> void:
	super._ready()
	moved.connect(moving)

func _process(delta: float) -> void:
	super._process(delta)
	if currentMode == Mode.IDLE:
		animation.play("Idle None")

func moving(delta: float, _direction: String, running: bool) -> void:
	if running:
		animation.play("Running None")
	else:
		animation.play("Walking None")

func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	var words : PackedStringArray = anim_name.split(' ')
	if(words[0].contains("Attack") || words[0].contains("Running") || words[0].contains("Walking") || words[0].contains("Hurt")):
		animation.play("Idle None")
