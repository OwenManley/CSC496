class_name enemyHitBox
extends Area2D

@export var damage := 10

func _init()-> void:
	collision_layer = 4
	collision_mask = 0
