extends AbstractNPC
class_name Friend

#################################################################################################### 
@onready var my_damage_box = $Sprite2D/enemyHurtBox
@onready var damage_numbers_origin = $DamageNumbersOrigin
#################################################################################################### 
var isAttacking : bool = false
var isMining : bool = false

func _ready() -> void:
	super._ready()
	tick.connect(friendTick)
	defense = 2

func _process(delta: float) -> void:
	super._process(delta)
	var shouldRun: bool = Input.is_action_pressed("run") || distance > 350
	var shouldStop: bool = distance < 32
	if hasCollision:
		$CollisionShape2D.set_deferred("disabled", distance > 350)
	
	if !shouldStop:
		if shouldUseNavigator:
			if navigation.is_target_reachable():
				var nextPathPoint: Vector2 = navigation.get_next_path_position() - global_position
				if nextPathPoint.x > -16:
					moveInDirection(delta, "right", shouldRun)
				if nextPathPoint.x < 16:
					moveInDirection(delta, "left", shouldRun)
				
				if nextPathPoint.y > -16:
					moveInDirection(delta, "down", shouldRun)
				if nextPathPoint.y < 16:
					moveInDirection(delta, "up", shouldRun)
		else:
			if player.position.x-16 > self.position.x:
				moveInDirection(delta, "right", shouldRun)
			if player.position.x+16 < self.position.x:
				moveInDirection(delta, "left", shouldRun)
			
			if player.position.y-16 > self.position.y:
				moveInDirection(delta, "down", shouldRun)
			if player.position.y+16 < self.position.y:
				moveInDirection(delta, "up", shouldRun)
	
	if abs(velocity.x) < 5 && abs(velocity.y) < 5:
		velocity.x = 0
		velocity.y = 0
	else:
		velocity.x = min(abs(velocity.x), abs(velocity.x * 0.75)) * sign(velocity.x)    #without these, we add the veolcity every frame
		velocity.y = min(abs(velocity.y), abs(velocity.y * 0.75)) * sign(velocity.y)    #these lines basically act as friction
	
	move_and_slide()

####################################################################################################
func _on_my_hitbox_area_entered(area: Area2D) -> void:
	pass # Replace with function body.


func _on_my_hitbox_body_entered(body: Node2D) -> void:
	if body.is_in_group("DamageCollider"):
		pass
		print("YAO")
	else:
		print(body.name)
####################################################################################################

func friendTick() -> void:
	health = min(health+1, MAX_HEALTH)
