extends Friend
class_name Brother

enum MainhandItem {
	NONE,
	PICKAXE,
	SWORD
}
var currentMainhandItem : MainhandItem = MainhandItem.NONE
var animationTypes : Dictionary = {
	MainhandItem.NONE : "None",
	MainhandItem.PICKAXE : "Pickaxe",
	MainhandItem.SWORD : "Sword"
}

var isJohnny: bool = false;

func _ready() -> void:
	super._ready()
	currentMainhandItem = [MainhandItem.NONE, MainhandItem.PICKAXE, MainhandItem.SWORD][randi_range(0,2)]
	moved.connect(moving)
	defense = 4
	
func _process(delta: float) -> void:
	if Globals.storyProgressIntroduction != 3 || self.position.distance_to(player.position) < 256:
		super._process(delta)
	
	if Globals.playerIsJohnny && isJohnny:
		$Sprite2D.texture = load("res://Assets/Player/james.png")
		isJohnny = false
	if !Globals.playerIsJohnny && !isJohnny:
		$Sprite2D.texture = load("res://Assets/Player/johnny.png")
		isJohnny = true
	
	if self.position.distance_to(player.position) < 32 && Globals.storyProgressIntroduction == 3:
		player.player_hud.displayDialogue([
			"Johnathan? Is that really you?",
			"James!\n Why, its been quiet the epoch since I last saw you!",
			"Indeed!\n But I'm afraid the others are in trouble!",
			"Oh?",
			"L-Let us head back to town and I'll explain..."
			],["james", "johnny", "james", "johnny", "james"],["happy", "happy", "serious", "thinking", "serious"], 0)
		Globals.storyProgressIntroduction = 4
		Globals.playerFriend = self.scene_file_path
	
	if velocity.x == 0 && velocity.y == 0 && (
		animation.current_animation.contains("Walking") || animation.current_animation.contains("Running")):
		animation.play("Idle " + animationTypes[currentMainhandItem])


func _on_timer_timeout() -> void:
	navigation.target_position = player.global_position

func moving(delta: float, direction: String, running: bool) -> void:
	if running:
		animation.play("Running " + animationTypes[currentMainhandItem])
	else:
		animation.play("Walking " + animationTypes[currentMainhandItem])

func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	var words : PackedStringArray = anim_name.split(' ')
	if(words[0].contains("Attack") || words[0].contains("Running") || words[0].contains("Walking") || words[0].contains("Hurt")):
		animation.play("Idle " + animationTypes[currentMainhandItem])
