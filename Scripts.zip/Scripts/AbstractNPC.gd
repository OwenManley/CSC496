extends CharacterBody2D
class_name AbstractNPC

signal moved
signal tick
#################################################################################################### 
@onready var player: CharacterBody2D = get_tree().get_nodes_in_group("Player")[0]
@onready var navigation: NavigationAgent2D = $Navigation/NavigationAgent2D
@onready var animation = $AnimationPlayer
@onready var shouldUseNavigator : bool = true
@onready var hasCollision : bool = true
@onready var distance : float = 10_000
@onready var internalTimer : float = 1_000
#################################################################################################### 
const REAL_SPEED : int = 1_000 
const SUPER_SPEED : int = 5_000
const MAX_HEALTH : float = 20

@onready var speed : int = REAL_SPEED
@onready var health : int = MAX_HEALTH
@onready var defense : int = 0
@onready var damage : int = 1

var isControllable : bool = true
var sprintMultiplier : int = 4

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	$CollisionShape2D.set_deferred("disabled", !hasCollision)

# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	distance = player.global_position.distance_to(self.global_position)
	internalTimer -= delta
	if internalTimer < 0:
		internalTimer = 1_000
		tick.emit()

func moveInDirection(delta: float, direction: String, running: bool) -> void:
	var velocityModifier = speed * delta
	if running:
		velocityModifier *= sprintMultiplier

	if direction.contains("right"):
		velocity.x += velocityModifier
		$Sprite2D.scale.x = 1
	if direction.contains("left"):
		velocity.x -= velocityModifier
		$Sprite2D.scale.x = -1
	if direction.contains("up"):
		velocity.y -= velocityModifier
	if direction.contains("down"):
		velocity.y += velocityModifier
	moved.emit(delta, direction, running)

func takeDamage(amount: int) -> void:
	health -= amount
	health = max(health, 0)
