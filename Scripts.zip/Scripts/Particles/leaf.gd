extends Node2D
@onready var fallingSpeed : float = 0.04
@onready var maxFallingSpeed : float = randf_range(0.1, 0.5)
@onready var rotationSpeed : float = randf_range(-0.04, 0.04)
@onready var fadeOut : bool = false
@onready var isBig : bool = false

# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	isBig = randf() <= 0.07
	if(isBig):
		$Sprite2D.region_rect = Rect2(randi_range(0,3)*16, 16, 16,16)
		self.z_as_relative = 199
		$Sprite2D.scale *= 2
		fallingSpeed = 0.08
		maxFallingSpeed *= 8
	else:
		$Sprite2D.region_rect = Rect2(randi_range(0,3)*16, 0, 16,16)
	$Sprite2D.flip_h = randf() <= 0.5
	await get_tree().create_timer(20.0).timeout
	fadeOut = true
	await get_tree().create_timer(5.0).timeout
	self.queue_free()


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	fallingSpeed = minf(fallingSpeed * 1.01, maxFallingSpeed) * get_meta("gravity_multiplier")
	self.global_position.y += fallingSpeed
	self.global_position.x += get_meta("wind_speed")
	self.rotate(rotationSpeed * get_meta("rotation_multiplier"))
	if(fadeOut):
		$Sprite2D.modulate.a -= 0.005
		
