extends DestructionParticle

func _ready() -> void:
	super._ready()
	$Sprite2D.region_rect = Rect2(randi_range(0,1)*8, randi_range(6,7)*8, 8,8)
