extends DestructionParticle

func _ready() -> void:
	super._ready()
	$Sprite2D.region_rect = Rect2(randi_range(0,1)*8, randi_range(8,9)*8, 8,8)
	self.z_index = randi_range(-1, 0)
