extends DestructionParticle

func _ready() -> void:
	super._ready()
	$Sprite2D.region_rect = Rect2(randi_range(0,7)*8, randi_range(4,5)*8, 8,8)
