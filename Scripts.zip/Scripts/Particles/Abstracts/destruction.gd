extends Node2D
class_name DestructionParticle 

@onready var horizontalSpeed
@onready var fallingSpeed : float = -1.95
@onready var rotationSpeed : float = randf_range(-0.04, 0.04)
@onready var fadeOut : bool = false

func _ready() -> void:
	$Sprite2D.flip_h = randf() <= 0.5
	if(horizontalSpeed == null):
		horizontalSpeed = randf_range(-0.8, 0.8)
	
	await get_tree().create_timer(0.2).timeout
	fadeOut = true
	await get_tree().create_timer(0.3).timeout
	self.queue_free()


func _process(_delta: float) -> void:
	fallingSpeed += 0.2
	self.global_position.y += fallingSpeed
	self.global_position.x += horizontalSpeed
	self.rotate(rotationSpeed)
	if(fadeOut):
		$Sprite2D.modulate.a -= 0.25
		
