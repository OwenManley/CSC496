extends AudioStreamPlayer

var offset: float = 0.0
var enabled: bool = true

func _ready() -> void:
	if enabled:
		self.volume_db = Globals.ambient_volume + offset
	else:
		self.volume_db = -80

func _process(delta: float) -> void:
	if Globals.is_changing_settings:
		self.volume_db = Globals.ambient_volume + offset

func enable(isEnabled: bool) -> void:
	enabled = isEnabled
	if !isEnabled:
		self.volume_db = -80
	else:
		self.volume_db = Globals.ambient_volume + offset
