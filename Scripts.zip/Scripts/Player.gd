extends CharacterBody2D

class_name Player

var particle = preload("res://Scenes/Particles/Destruction/grass.tscn")

enum MainhandItem {
	NONE,
	PICKAXE,
	SWORD
}
var currentMainhandItem : MainhandItem = MainhandItem.NONE
var animationTypes : Dictionary = {
	MainhandItem.NONE : "None",
	MainhandItem.PICKAXE : "Pickaxe",
	MainhandItem.SWORD : "Sword"
}
var baseDamageTypes : Dictionary = {
	MainhandItem.NONE : 2.0,
	MainhandItem.PICKAXE : 4.0,
	MainhandItem.SWORD : 10.0
}
var hasTools : bool = true;

const REAL_SPEED : int = 1_000 
const SUPER_SPEED : int = 5_000
const MAX_HEALTH : float = 20

@onready var speed : int = REAL_SPEED # Joe: NEVER set to 0, use the isControllable boolean instead.
@onready var knockbackPower : int = 2_000 #determines how far the player gets knocked back
@onready var luck : float = 1.0 # Joe: Not used yet.

@onready var defense : float = 0.0 # Joe: Not used yet.
@onready var damageMultiplier : float = 1.0 # Joe: Use the getDamage function.
@onready var playerHealth : float = MAX_HEALTH

#################################################################################################### 
@onready var player_hud = $"Player Hud" # The Player's HUD / Stats
@onready var pause_menu = $PauseMenu
@onready var animation = $AnimationPlayer
@onready var boxy = $TheKnight/myHitbox/hitbox #the sword hitbox
@onready var miny = $TheKnight/myAttackRock/RockAttack #the mining hitbox
@onready var damage_numbers_origin = $DamageNumbersOrigin #where the damage numbers pop out of the player
####################################################################################################
var isAttacking : bool = false #is the player attacking?
var isMining : bool = false #is the player minig?
var isAlive : bool = true #is the player alive? used to play the death animation & sound only once per death (prevents multiple things playing if the player gets hit again after death)
var isControllable : bool = true # Joe: Can the player move?
var paused : bool = false
var isInvincible : bool = false # Joe: Used for Iframes
var sprintMarkiplier : int = 3 #sprintMultiplier but funnier name
####################################################################################################
func _on_ready() -> void:
	player_hud.visible = true
	player_hud.update_health(Globals.playerHealth, MAX_HEALTH, false)
	if Globals.playerFriend != null && !Globals.playerFriend.is_empty():
		var node: CharacterBody2D = ResourceLoader.load(Globals.playerFriend).instantiate()
		self.get_parent().call_deferred("add_child", node)
		node.owner = self.get_parent()
		await get_tree().create_timer(0.01).timeout
		node.position = self.position + Vector2(32, 0)
####################################################################################################
func _physics_process(delta: float) -> void:
	tryToStowTools()
	if Input.is_action_just_pressed("pause"):
		pauseMenu()

	if Input.is_action_just_pressed("godMode"): # No Damage
		$TheKnight/enemyHurtBox/CollisionShape2D2.set_deferred("disabled", !$TheKnight/enemyHurtBox/CollisionShape2D2.disabled)
		player_hud.displayDialogue(
			["Sigmoid " + ("Off" if $TheKnight/enemyHurtBox/CollisionShape2D2.disabled else "On")],["sigma"],["serious"], 0)

	if Input.is_action_just_pressed("noclip"): # No Collision
		$CollisionShape2D.set_deferred("disabled", !$CollisionShape2D.disabled)
		player_hud.displayDialogue(
			["Noclip " + ("Off" if $CollisionShape2D.disabled else "On")],["hampter"],["serious"], 0)

	if Input.is_action_just_pressed("fleetFeet"): # Quick Movement Speed
		speed = SUPER_SPEED if speed != SUPER_SPEED else REAL_SPEED
		animation.speed_scale = speed / REAL_SPEED
		player_hud.displayDialogue(
			["Fleet Feet " + ("Off" if speed != SUPER_SPEED else "On")],["sigma"],["serious"], 0)
	
	if Input.is_action_just_pressed("skinswap"): # Changes Current Player
		if Globals.playerIsJohnny:
			$TheKnight.texture = load("res://Assets/Player/james.png")
		else:
			$TheKnight.texture = load("res://Assets/Player/johnny.png")
		Globals.playerIsJohnny = !Globals.playerIsJohnny
		player_hud.displayDialogue(
			["Luigi " + ("Off" if Globals.playerIsJohnny else "On")],["hampter"],["serious"], 0)
		addAnother()

	if(isInvincible && !isControllable):
		animation.play("Hurt")
		return
	
	if abs(velocity.x) < 5 && abs(velocity.y) < 5:
		velocity.x = 0
		velocity.y = 0
	else:
		velocity.x = min(abs(velocity.x), abs(velocity.x * 0.75)) * sign(velocity.x)    #without these, we add the veolcity every frame
		velocity.y = min(abs(velocity.y), abs(velocity.y * 0.75)) * sign(velocity.y)    #these lines basically act as friction
	#print(str($".".global_position.x) + ", " + str($".".global_position.y))
	if(isControllable):
		if Input.is_action_pressed("move-left"):
			moveInDirection(delta, "left", Input.is_action_pressed("run"))
		if Input.is_action_pressed("move-right"):
			moveInDirection(delta, "right", Input.is_action_pressed("run"))
		if Input.is_action_pressed("move-up"):
			moveInDirection(delta, "up", Input.is_action_pressed("run"))
		if Input.is_action_pressed("move-down"):
			moveInDirection(delta, "down", Input.is_action_pressed("run"))

		if velocity.x == 0 && velocity.y == 0 && (
			animation.current_animation.contains("Walking") || animation.current_animation.contains("Running")):
			animation.play("Idle " + animationTypes[currentMainhandItem])

		if hasTools :
			if Input.is_action_pressed("Pickaxe") && velocity.x == 0 && velocity.y == 0: #was right mouse button clicked/held down?
				animation.play("Attack Pickaxe")
				currentMainhandItem = MainhandItem.PICKAXE
				isMining = true
			if Input.is_action_just_released("Pickaxe"): #was left mouse button released?
				isMining = false
				miny.disabled = true

			if Input.is_action_pressed("Attack1") && velocity.x == 0 && velocity.y == 0: #was left mouse button clicked/held down?
				#velocity.x = 0   
				#velocity.y = 0
				animation.play("Attack Sword")
				currentMainhandItem = MainhandItem.SWORD
				isAttacking = true
			if Input.is_action_just_released("Attack1"): #was left mouse button released?
				isAttacking = false
				boxy.disabled = true
			
		if(animation.current_animation == "Running None" && 
		!get_tree().current_scene.scene_file_path.begins_with("res://Scenes/Levels/Mines") && 
		!get_tree().current_scene.scene_file_path.begins_with("res://Scenes/Levels/BuildingInteriors") &&
		randf() <= 0.1):
			spawn_grass_particles() # Spawn particles only when the player is sprinting and not in a mines level.
		#for body in $TheKnight/myHitbox.get_overlapping_bodies():
			#if knockbackWait <= 0 and body.is_in_group("Enemies"):
				#print("knockback")
	move_and_slide()   #always have at BOTTOM of code, not top

####################################################################################################
func moveInDirection(delta: float, direction: String, running: bool) -> void:
	var velocityModifier = speed * delta
	if running:
		velocityModifier *= sprintMarkiplier
		animation.play("Running " + animationTypes[currentMainhandItem])
	else:
		animation.play("Walking " + animationTypes[currentMainhandItem])

	if direction.contains("right"):
		velocity.x += velocityModifier
		$TheKnight.scale.x = 1
	if direction.contains("left"):
		velocity.x -= velocityModifier
		$TheKnight.scale.x = -1
	if direction.contains("up"):
		velocity.y -= velocityModifier
	if direction.contains("down"):
		velocity.y += velocityModifier
####################################################################################################
func take_damage(amount: int) -> void: #amount is the damage taken
	#print("Damage: ", amount) #prints the damage taken to the console
	print("IFrames: ", isInvincible)
	if(isInvincible):
		return
	isInvincible = true

	Globals.playerHealth -= amount
	#Globals.playerHealth = playerHealth
	#print(Globals.playerHealth)
	if(Globals.playerHealth > 0):
		knockback() #gets the enemy velocity to knockback the player
		PlayerDamageNumbersgd.display_number(amount, damage_numbers_origin.global_position) #, is_critical
		player_hud.update_health(Globals.playerHealth, MAX_HEALTH, true)
		$TheKnight/enemyHurtBox.set_deferred("disabled", true)
		#$CollisionShape2D.set_deferred("disabled", true) #makes it so that the player doesn't get stuck between enemy and fence, but also makes it so that yo ucan just walk right through the fence??
		await get_tree().create_timer(0.35).timeout
		isInvincible = false
		await get_tree().create_timer(1.65).timeout
		$TheKnight/enemyHurtBox.set_deferred("disabled", false)
		#$CollisionShape2D.set_deferred("disabled", false)
	else: #damage is kil
		if(isAlive == true): #if the player was not previously dead, do these things
			isControllable = false
			$TheKnight/enemyHurtBox/CollisionShape2D2.set_deferred("disabled", true)
			$deathSounds.play()
			player_hud.visible = false
			updateZone(1) #removes the HUD from the death animation
			velocity = Vector2(0,0)
			#print("going dark")
			animation.play("ded")
			await get_tree().create_timer(2.0).timeout
			$dieded.dark()
			print("dark now")
			await get_tree().create_timer(2.0).timeout
			isAlive = false
		$DamageNumbersOrigin.visible = false
		Globals.playerPositionX = 258
		Globals.playerPositionY = 111
		Globals.playerHealth = 20
		Globals.lastKnownHouse = Globals.Houses.HOSPITAL
		get_tree().change_scene_to_file(Globals.mapIndoors)
		#currently, the entire scene just reloads if the player dies
		#can change this to be like Stardew Valley where if the player dies, a hospital scene is loaded?
		#get_tree().reload_current_scene() 
####################################################################################################
func updateZone(zone: int):
	if(zone == 1): #no HUD; used in death animation
		$HUD.visible = false
		#print("zoner 1")
	elif(zone == 2): #zone above ground; used for the funny secret
		pass
		"""
		var catty = randi() % 100
		if(catty == 58): #58
			$HUD.turn_on_cat()
		#print("catty is " + str(catty))
		#print("zone 2")
		"""
	elif(zone == 3): #zone below ground
		$HUD.turn_on_mining()
		print("miney time")
	#elif(zone == 4): 
		#print("zone 4")
####################################################################################################
func updateMineDepth(level: int):
	$"Player Hud".update_level(level)
####################################################################################################
func knockback():
	var knockbackDirection = -velocity.normalized() * knockbackPower
	velocity = knockbackDirection
	move_and_slide()
####################################################################################################
func getDamage() -> float:
	return damageMultiplier * baseDamageTypes[currentMainhandItem]
####################################################################################################
func stopMovingForABit():
	isControllable = false
	print("slow time")
	await get_tree().create_timer(.75).timeout
	isControllable = true
	print ("normal time")
####################################################################################################	
func spawn_grass_particles() -> void:
	var object: DestructionParticle = particle.instantiate()
	object.position = Vector2(randi_range(-4, 4), randi_range(0, 1)+12 )
	object.horizontalSpeed = (-velocity.x / speed) * 30
	add_child(object)
####################################################################################################
func pauseMenu():
	if paused:
		pause_menu.hide()
		Engine.time_scale = 1
	else:
		var connected_joysticks  = Input.get_connected_joypads()
		if ((connected_joysticks.size() > 0)):
			$PauseMenu/MenuButtons/ScaleHandler_Resume/Button.grab_focus()
		pause_menu.show()
		Engine.time_scale = 0
	paused = !paused
####################################################################################################
# "Player has access to the inventory,
#then are inserting items into it." Items in this case are the pick-up-ables.	
func collect(item):
	Globals.inventory.insert(item)
####################################################################################################
func tryToStowTools() -> void:
	if currentMainhandItem == MainhandItem.PICKAXE && $"Player Radius".get_overlapping_bodies().filter(
		func(node: Node): 
			return node.get_parent().get_script() && node.get_parent().get_script().get_global_name().contains("Rock")).is_empty():
		currentMainhandItem = MainhandItem.NONE
####################################################################################################
func _on_animation_player_animation_finished(anim_name: StringName) -> void:
	var words : PackedStringArray = anim_name.split(' ')
	if(words[0].contains("Attack") || words[0].contains("Running") || words[0].contains("Walking") || words[0].contains("Hurt")):
		animation.play("Idle " + animationTypes[currentMainhandItem])
####################################################################################################
func addAnother(): #adds another friend
	Globals.playerFriend = "res://Scenes/NPCs/Brother.tscn";
	var node: CharacterBody2D = ResourceLoader.load(Globals.playerFriend).instantiate()
	self.get_parent().call_deferred("add_child", node)
	node.owner = self.get_parent()
	node.position = self.position + Vector2(30, 30)
