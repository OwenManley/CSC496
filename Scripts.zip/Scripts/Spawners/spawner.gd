extends Node2D

var tile_map : TileMapLayer
var tile_coords
@onready var rate_multiplier : float = get_meta("multiplier") * 0.2 # Multiplier can be 1-5
@onready var x_range : int = get_meta("x_range") # Horizontal range/radius in tiles.
@onready var y_range : int = get_meta("y_range") # Vertical range/radius in tiles.
@onready var spawn_during_play : bool = get_meta("spawn_during_play")
@onready var origin = (self.position / 16).floor()
@onready var spawn_chances = [100, 50, 25, 5] # Each tile will roll a 20% chance before trying this.
@onready var children # Attach child nodes to the Spawner in the 2D editor.
var object : Node

# Called when the node enters the scene tree for the first time.
#func _ready() -> void:
	#$Overlay.hide()
	#self.position = origin*16 + Vector2(8,8)
	#
	#tile_map = get_node("../TileMap Layers/Spawn Map")
	#if(tile_map == null):
		#print("Level is missing a \"Spawn Map\" tile layer.")
		#self.queue_free()
		#return
	#else:
		#print("Spawn Tilemaps will be hidden in gameplay.")
		#tile_map.hide()
	#
	#children = get_children().filter(
		#func(a: Node): return a.scene_file_path.contains("Interactable Objects/") || a.scene_file_path.contains("Enemies/")
		#)
	#print(children)
	##print("Spawner Pos: ", self.position, origin)
	##print("Spawner X Range: ", origin.x - x_range, " ", origin.x + x_range)
	##print("Spawner Y Range: ", origin.y - y_range, " ", origin.y + y_range)
#
	#if(!spawn_during_play):
		#_scan()
		#for child in children:
			#child.queue_free()
	#else:
		#for child in children:
			#child.position = Vector2(-9999999999, -9999999999)

func execute():
	$Overlay.hide()
	self.position = origin*16 + Vector2(8,8)
	
	tile_map = get_node("../TileMap Layers/Spawn Map")
	if(tile_map == null):
		print("Level is missing a \"Spawn Map\" tile layer.")
		self.queue_free()
		return
	else:
		print("Spawn Tilemaps will be hidden in gameplay.")
		tile_map.hide()
	
	children = get_children().filter(
		func(a: Node): return a.scene_file_path.contains("Interactable Objects/") || a.scene_file_path.contains("Enemies/")
		)
	print(children)
	#print("Spawner Pos: ", self.position, origin)
	#print("Spawner X Range: ", origin.x - x_range, " ", origin.x + x_range)
	#print("Spawner Y Range: ", origin.y - y_range, " ", origin.y + y_range)

	if(!spawn_during_play):
		_scan()
		for child in children:
			child.queue_free()
	else:
		for child in children:
			child.position = Vector2(-9999999999, -9999999999)


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(_delta: float) -> void:
	if(spawn_during_play && randf() <= 0.02):
		_pick_random_pos()

func _scan():
		for x in range(origin.x - x_range, origin.x + x_range):
			for y in range(origin.y - y_range, origin.y + y_range):
				if(randf() <= rate_multiplier && x != 0 && y != 0):
					object = children.pick_random()
					_try_spawn(x, y)

func _pick_random_pos():
	var x = randi_range(origin.x - x_range, origin.x + x_range)
	var y = randi_range(origin.y - y_range, origin.y + y_range)
	if(randf() <= rate_multiplier && x != 0 && y != 0):
		object = children.pick_random()
		_try_spawn(x, y)

func _try_spawn(x_pos : int, y_pos : int):
	tile_coords = tile_map.get_cell_atlas_coords( Vector2(x_pos, y_pos) )
	#print("Try at: ", Vector2(x_pos, y_pos))
	if(tile_coords.x >= 0 && randf() <= spawn_chances[tile_coords.x]/100.0):
		
		var sprite = object.get_children().filter(
			func(a : Node): return a is Sprite2D
		)
		if(sprite.is_empty()):
			sprite = object.get_children().filter(
			func(a : Node): return a is AnimatedSprite2D
		)
			if(sprite.is_empty()):
				print("This is not a valid object! ", object)
				return
			else:
				#print("AnimatedSprite2D ", object)
				sprite = sprite[0]
		else:
			#print("Sprite2D ", object)
			sprite = sprite[0]
		
		
		if(sprite is Sprite2D):
			
			if(
				!self.get_children().filter(
				func(a: Node): 
				var other_sprite = (a.get_children().filter(func(b : Node): return b is Sprite2D))
				if(!other_sprite.is_empty()):
					other_sprite = other_sprite[0]
					if(other_sprite is Sprite2D):
						return other_sprite.get_rect().has_point(
							Vector2((x_pos - origin.x)*16, (y_pos - origin.y)*16) - a.position
							) || other_sprite.get_rect().has_point(
							Vector2((x_pos - origin.x)*16, (y_pos - origin.y)*16 + other_sprite.get_rect().size.x-1) - a.position
							)
				return false
				).is_empty()
			): 
				return

			
			if(sprite.get_rect().size.x > 30):
					var scale = int(sprite.get_rect().size.x/16) - 1
					tile_coords = tile_map.get_cell_atlas_coords( Vector2(x_pos+scale, y_pos+scale) )
					if(tile_coords.x >= 0):
						_spawn(x_pos, y_pos)
						return
			else:
				_spawn(x_pos, y_pos)
		
		if(sprite is AnimatedSprite2D):
			_spawn(x_pos, y_pos)

		#print("Pass: ", tile_coords, Vector2(x_pos, y_pos))
		return
	else:
		#print("Fail: ", tile_coords, Vector2(x_pos, y_pos))
		return
		
func _spawn(x_pos : int, y_pos : int):
		var item : Node = ResourceLoader.load(object.scene_file_path).instantiate()
		#Object.new()
		#PackedScene.new().instantiate()
		
		#print("New Item: ", item)
		#print("Is Item Ready: ", item.is_node_ready())
		item.position = Vector2((x_pos - origin.x)*16, (y_pos - origin.y)*16)
		if(object is AnimatedSprite2D || object is CharacterBody2D):
			add_child(item)
			return
		
		
		var sprite = item.get_children().filter(
			func(a : Node): return a is Sprite2D
		)[0]
		if(sprite is Sprite2D):
			#print("RECT: ", sprite.get_rect().size.x, " ", sprite.get_rect().size.y)
			if(sprite.get_rect().size.x > 30):
				item.position = item.position + (Vector2(
					sprite.get_rect().size.x/16,
					sprite.get_rect().size.y/16
					).floor() * 4) 
				#print("RECT: ", sprite.get_rect().size.x/16, " ", sprite.get_rect().size.y/16)
				
		#print("Item Pos: ", item.position, Vector2(x_pos, y_pos))
		add_child(item)
