extends Node2D

var mines = "res://Scenes/Levels/Mines/minesTheme1.tscn"
var firstTownArea = "res://Scenes/Levels/OutsideAreas/firstTownArea.tscn"
var leaf_particle = preload("res://Scenes/Particles/leaf.tscn")

func _on_ready() -> void:
	if Globals.storyProgressIntroduction != 3:
		remove_child($Brother)
	$Spawner.execute()
	$Player.set_position(Vector2(Globals.playerPositionX, Globals.playerPositionY))
	Globals.currentScene = "res://Scenes/Levels/OutsideAreas/Mount_Haven.tscn"
	$Player.updateZone(2)
	$AnimationPlayer.play("fade in")
	$"TileMap Layers/Bridges".visible = false
	if !Globals.hasPlayerVisitedMinesYet && (Globals.previousScene == mines):
		Globals.timeOfDay = 0.0
		print("Ste time")
		#$Player/Dialogue.displayDialogue(5, 7, 1.5)
		$Player/"Player Hud".displayDialogue(
			["That was scary!", "Maybe I should try returning back to Ironhaven."],
			["johnny", "johnny"],["scared", "serious"], 1.5)

	$Player.stopMovingForABit()
	$"Area2D-Mine Entrance/Box-MineEntrance".set_deferred("disabled", true)
	await get_tree().create_timer(2.0).timeout
	$"Area2D-Mine Entrance/Box-MineEntrance".set_deferred("disabled", false)
	

func _process(_delta: float) -> void:
	_handle_falling_leaves()

func _handle_falling_leaves() -> void:
	if(randf() <= 0.065):
		var object = leaf_particle.instantiate()
		var pos = $Player.damage_numbers_origin.global_position
		object.position = Vector2(
			pos.x + randi_range(-DisplayServer.screen_get_size().x, DisplayServer.screen_get_size().x)/2,
			pos.y - (DisplayServer.screen_get_size().y/4)
			)
		object.set_meta("wind_speed", Globals.windSpeed)
		add_child(object)

func _on_area_2d_bridge_under_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"TileMap Layers/Collidable Props2".z_index = 1
		$"TileMap Layers/Collidable Props2".y_sort_enabled = false
		$"TileMap Layers/Collidable Props2".collision_enabled = false
		$"Box-BridgeBorders/CollisionShape2D".set_deferred("disabled", false)
		$"Box-BridgeBorders/CollisionShape2D2".set_deferred("disabled", false)
		$"TileMap Layers/Bridges".visible = true
		$"Area2D-BridgeUnder/Box-BridgeUnder".set_deferred("disabled", true)
		$"Area2D-BridgeOutFromUnder/Box-BridgeOutFromUnder".set_deferred("disabled", false)
		$"Area2D-BridgeOutFromUnder/Box-BridgeOutFromUnder2".set_deferred("disabled", false)

func _on_area_2d_bridge_out_from_under_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"TileMap Layers/Collidable Props2".z_index = 0
		$"TileMap Layers/Collidable Props2".y_sort_enabled = true
		$"TileMap Layers/Collidable Props2".collision_enabled = true
		$"Box-BridgeBorders/CollisionShape2D".set_deferred("disabled", true)
		$"Box-BridgeBorders/CollisionShape2D2".set_deferred("disabled", true)
		$"TileMap Layers/Bridges".visible = false
		$"Area2D-BridgeUnder/Box-BridgeUnder".set_deferred("disabled", false)
		$"Area2D-BridgeOutFromUnder/Box-BridgeOutFromUnder".set_deferred("disabled", true)
		$"Area2D-BridgeOutFromUnder/Box-BridgeOutFromUnder2".set_deferred("disabled", true)

func _on_area_2d_mine_entrance_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		if Globals.storyProgressIntroduction < 3:
			Globals.storyProgressIntroduction = 3
		$AnimationPlayer.play("fade out")
		Globals.previousScene = Globals.currentScene
		get_tree().change_scene_to_file(mines)

func _on_area_2d_back_to_town_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$AnimationPlayer.play("fade out")
		Globals.playerPositionX = 1876
		Globals.playerPositionY = 1242
		if $Player/"Player Hud"/Filters/Night.visible && (Globals.previousScene == mines):
			Globals.hasPlayerVisitedMinesYet = true
		Globals.previousScene = Globals.currentScene
		get_tree().change_scene_to_file(firstTownArea)
