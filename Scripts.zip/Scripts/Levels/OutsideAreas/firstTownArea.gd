extends Node2D

#player is not slowed down when crossing bridge in this scene, no buildings will be open

const TILEMAP_COLLISIONS = [true, true, true, true, true, true, false, false]
var echoNodes : Array[AudioStreamPlayer]
var isInCave : bool = false

#var houseLocationsOutside : Dictionary = { # OUTSIDE
	#Globals.Houses.NONE : Vector2i(1216,-16), # Default to hospital.
	#Globals.Houses.HOSPITAL : Vector2i(1216,-16), Globals.Houses.BLACKSMITH : Vector2i(344,-776),
	#Globals.Houses.ALCHEMIST : Vector2i(48,184), Globals.Houses.WIZARD : Vector2i(968,-1808),
#}

@onready var houseLocationsOutsideSmart : Dictionary = { # OUTSIDE
	Globals.Houses.NONE : $"Entrances/Area2D-Hospital/Box".global_position,
	Globals.Houses.HOSPITAL : $"Entrances/Area2D-Hospital/Box".global_position, 
	Globals.Houses.BLACKSMITH : $"Entrances/Area2D-Smith/Box".global_position,
	Globals.Houses.ALCHEMIST : $"Entrances/Area2D-Alchemist/Box".global_position, 
	Globals.Houses.WIZARD : $"Entrances/Area2D-Wizard/Box".global_position,
}

func _process(_delta: float) -> void:
	if Input.is_action_just_released("fadeToBlack"):
		print("EPIC")
		$AnimationPlayer.play("fade out")
		await get_tree().create_timer(1.9).timeout
		$ColorRect3.visible = true


func _on_ready() -> void:
	if Globals.lastKnownHouse == 0:
			if Globals.storyProgressIntroduction > 1:
				$Player.set_position(Vector2(Globals.playerPositionX, Globals.playerPositionY))
	else:
		$Player.set_position(houseLocationsOutsideSmart.get(Globals.lastKnownHouse) + Vector2(0,36))
		
		
	Globals.currentScene = "res://Scenes/Levels/OutsideAreas/firstTownArea.tscn"
	$Player.updateZone(1) #no HUD instructions
	#$Player.stopMovingForABit()
	#if Globals.hasPlayerVisitedMinesYet:
		#playerHasVisitedMines()
		#buildingsUnlocked()
	#else:
		#playerHasNotVisitedMines()
	
	
	if Globals.storyProgressIntroduction == 1:
		if Globals.lastKnownHouse == 0:
			$CutsceneHandler.townFirst()
		$"TileMap Layers/Collidable Props".set_cell(Vector2i(46,-100), 0, Vector2i(14,7))
		$"TileMap Layers/Collidable Props".set_cell(Vector2i(47,-100), 0, Vector2i(15,7))
		$"TileMap Layers/Collidable Props".set_cell(Vector2i(48,-100), 0, Vector2i(16,7))
	else:
		$"TileMap Layers/Collidable Props".set_cell(Vector2i(-1,33), 0, Vector2i(16,14))
		$"TileMap Layers/Collidable Props".set_cell(Vector2i(-2,33), 0, Vector2i(15,14))
		$"TileMap Layers/Collidable Props".set_cell(Vector2i(-3,33), 0, Vector2i(14,14))

	if Globals.storyProgressIntroduction == 4 && Globals.lastKnownHouse == 0:
		$CutsceneHandler.townFirstJames()

	
	for i in range(3):
		echoNodes.append($"Audio Players/Music".duplicate())
		$"Audio Players".call_deferred("add_child", echoNodes[i])
		echoNodes[i].call_deferred("stop")
		echoNodes[i].offset = -abs(10.0 * (i*i+1)) # 1 2 5 
		#print(echoNodes[i].offset)
	for i in range(3):
		echoNodes.append($"Audio Players/Ambient".duplicate())
		$"Audio Players".call_deferred("add_child", echoNodes[i+3])
		echoNodes[i+3].call_deferred("stop")
		echoNodes[i+3].offset = -abs(10.0 * (i*i+1)) # 1 2 5 
	
	if Globals.lastKnownHouse != Globals.Houses.BLACKSMITH: 
		_on_area_2d_mines_exit_body_entered($Player, true)
	else:
		_on_area_2d_mines_enter_body_entered($Player)
	Globals.lastKnownHouse = 0
	

func _on_area_2d_bridge_body_exited(body: Node2D) -> void:
	if(body.is_in_group("Player") == true && Globals.storyProgressIntroduction == 1):
		Globals.storyProgressIntroduction = 2
		$Player.player_hud.displayDialogue(
			["Odd, I wonder where everyone went?", "Hmm...", "The mines used to be quite busy back in the day,", "Perhaps I should check them out."],
			["johnny", "johnny", "johnny", "johnny"],["thinking", "thinking", "serious", "thinking"], 0)

func _on_area_2d_leave_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #only if the player collides with this box will the scene change
		Globals.playerPositionX = -304
		Globals.playerPositionY = 1184
		Globals.previousScene = Globals.currentScene
		get_tree().change_scene_to_file(Globals.mapMountHaven)

func _on_area_2d_bridge_sounds_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$Player.speed = 750
		var audioPlayer = $"Audio Players/Music"
		audioPlayer.stream = load("res://Assets/Audio/Ambient Music/1-50. Skyarrow Bridge.mp3")
		audioPlayer.volume_db = -15
		audioPlayer.play()

func _on_area_2d_bridge_sounds_body_exited(_body: Node2D) -> void:
	var audioPlayer = $"Audio Players/Music"
	audioPlayer.stream = load("res://Assets/Audio/Ambient Music/1-17. Accumula Town.mp3")
	audioPlayer.volume_db = -25
	audioPlayer.play()

func playerHasVisitedMines() -> void:
	#player HAS visited the mines and made it back to town at least one time
	$"Area2D-BridgeSounds/Box-BridgeSounds".set_deferred("disabled", false)
	$"Area2D-Bridge/Box-Bridge".set_deferred("disabled", true)
	#unlock hospital
	$"Area2D-Hospital/Box-Hospital".set_deferred("disabled", false)
	#close the fence in the bottom left and clean up tree in top middle
	$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(-2,32), 0, Vector2i(14,0))
	$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(-1,32), 0, Vector2i(15,0))
	$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(0,32), 0, Vector2i(15,0))
	$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(1,32), 0, Vector2i(16,0))


func playerHasNotVisitedMines() -> void:
	$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(8,-48), 0, Vector2i(4,4))
	$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(8,-49), 0, Vector2i(4,3))
	$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(8,-50), 0, Vector2i(4,2))

# All colliders use this method, you can EDIT the signal to add a unique int value (based on the global enum).
func playerMaybeEnterBuilding(body: Node2D, building: int) -> void:
		if(body.is_in_group("Player") == true): 
			Globals.lastKnownHouse = building
			Globals.previousScene = Globals.currentScene
			get_tree().change_scene_to_file(Globals.mapIndoors)

func buildingsUnlocked() -> void:
	pass


func _on_area_2d_mines_exit_body_entered(body: Node2D, _override: bool = false) -> void:
	if(body.is_in_group("Player") && isInCave || _override):
		isInCave = false
		
		if(!_override):
			$Player.player_hud.fadeScreen(0.25, Color.WHEAT, Color.WHEAT)
			$Player.player_hud.upToDate = false
			$Player.isControllable = false
			await get_tree().create_timer(0.25).timeout
			$Player.isControllable = true

		if body.global_position.y > -806:
			$"Borders/Top World Border".set_deferred("disabled", false)
		$"Alt TileMap Layers".visible = false
		$"Alt TileMap Layers".enabled = false
		var children : Array[Node] = $"Alt TileMap Layers".get_children()
		for i: int in children.size():
			children[i].collision_enabled = false
		
		children = $"TileMap Layers".get_children()
		for i: int in children.size():
			children[i].collision_enabled = TILEMAP_COLLISIONS[i]
		
		$Signs/CautionSign.position.y = -800
		$"Signs/Temp Smith".position.y = 5_000
		$Houses/Blacksmith.visible = false
		$"Audio Players/Waterfall2".play()
		
		for i in range(6):
			echoNodes[i].stop()
		
		resetFriend(true)
		$"Audio Players/Music".enable(true)
		$"Audio Players/Ambient".enable(true)
		$"TileMap Layers".visible = true
		$"TileMap Layers".enabled = true


func _on_area_2d_mines_enter_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") && !isInCave):
		isInCave = true
		
		$Player.player_hud.fadeScreen(0.25)
		$"Player/Player Hud/Filters/Night".visible = false
		$Player.isControllable = false
		await get_tree().create_timer(0.25).timeout
		$Player.isControllable = true
		
		$"Borders/Top World Border".set_deferred("disabled", true)
		$"Alt TileMap Layers".visible = true
		$"Alt TileMap Layers".enabled = true
		var children : Array[Node] = $"Alt TileMap Layers".get_children()
		for i: int in children.size():
			children[i].collision_enabled = TILEMAP_COLLISIONS[i]
		
		children = $"TileMap Layers".get_children()
		for i: int in children.size():
			children[i].collision_enabled = false
		
		$Signs/CautionSign.position.y = 5_000
		$"Signs/Temp Smith".position.y = -808
		$Houses/Blacksmith.visible = true
		
		$"Audio Players/Waterfall2".stop()
		
		for i in range(3):
			echoNodes[i].play()
			echoNodes[i].seek($"Audio Players/Music".get_playback_position() - i * 0.1) #0.1
		for i in range(3):
			echoNodes[i+3].play()
			echoNodes[i+3].seek($"Audio Players/Ambient".get_playback_position() - i * 0.1) #0.1

		resetFriend(false)
		$"Audio Players/Music".enable(false)
		$"Audio Players/Ambient".enable(false)
		$"TileMap Layers".visible = false
		$"TileMap Layers".enabled = false

func resetFriend(isLeaving: bool):
		if !Globals.playerFriend.is_empty() && !$"TileMap Layers".visible:
			var friends: Array[Node] =  get_tree().get_nodes_in_group("PlayerFriends") 
			var dist: float = 8
			if $Player.global_position.y > -806:
				for i: int in friends.size():
					friends[i].position = $Player.position - Vector2(0, dist + dist*i) 
			else:
				for i: int in friends.size():
					friends[i].position = $Player.position + Vector2(0, dist + dist*i)

	
