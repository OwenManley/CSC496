extends Node2D

#this is the first time the player enters the central zone, so when they leave for the towns they will
#enter the first copy where they are not slowed down across the bridge, and when they enter the mines
#they enter the version of the mines where they are kicked out after 4 levels

var firstMines = "res://Scenes/Levels/Mines/minesTheme1.tscn"
var firstTownArea = "res://Scenes/Levels/OutsideAreas/firstTownArea.tscn"
var leaf_particle = preload("res://Scenes/Particles/leaf.tscn")

func _on_ready() -> void:
	$Spawner.execute()
	Globals.currentScene = "res://Scenes/Levels/OutsideAreas/firstCentralZone.tscn"
	$AudioStreamPlayer.play()
	$Player.updateZone(2)

func _process(_delta: float) -> void:
	_handle_falling_leaves()

func _on_mine_entrance_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #prevents the staticborder from counting as entering the ladder
		Globals.previousScene = Globals.currentScene
		get_tree().change_scene_to_file(firstMines)

func _on_back_to_first_town_area_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #prevents the staticborder from counting as entering the ladder
		Globals.playerPositionX = 1876
		Globals.playerPositionY = 1242
		Globals.previousScene = Globals.currentScene
		get_tree().change_scene_to_file(firstTownArea)
		
func _handle_falling_leaves() -> void:
	if(randf() <= 0.065):
		var object = leaf_particle.instantiate()
		var pos = $Player.damage_numbers_origin.global_position
		object.position = Vector2(
			pos.x + randi_range(-DisplayServer.screen_get_size().x, DisplayServer.screen_get_size().x)/2,
			pos.y - (DisplayServer.screen_get_size().y/4)
			)
		#print(pos, "   ", object.position)
		add_child(object)
