extends Node2D

#is played once, when the player leaves the mines for the very first time

var firstMines = "res://Scenes/Levels/Mines/minesTheme1.tscn"
var mainTownArea = "res://Scenes/Levels/OutsideAreas/firstTownArea.tscn"

func _on_ready() -> void:
	$Player.set_position(Vector2(Globals.playerPositionX, Globals.playerPositionY))
	Globals.currentScene = "res://Scenes/Levels/OutsideAreas/spookyCentralZone.tscn"
	$Player.updateZone(2)
	$darkener.visible = true
	$AnimationPlayer.play("fade in")
	$AudioStreamPlayer.play()
	$Player/Dialogue.displayDialogue(5, 7, 1.5)
	$"Mine Entrance/CollisionShape2D".set_deferred("disabled", true)
	await get_tree().create_timer(2.0).timeout
	$"Mine Entrance/CollisionShape2D".set_deferred("disabled", false)

func _on_mine_entrance_body_entered(body: Node2D) -> void:
	#await get_tree().create_timer(5.0, true, false, true).timeout #makes a delay
	$AnimationPlayer.play("fade out")
	if(body.is_in_group("PlayerBorders") == false): #prevents the staticborder from counting as entering the ladder
		get_tree().change_scene_to_file(firstMines)

func _on_town_collision_area_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #prevents the staticborder from counting as entering the ladder
		$AnimationPlayer.play("fade out")
		Globals.playerPositionX = 1876
		Globals.playerPositionY = 1242
		Globals.hasPlayerVisitedMinesYet = true
		get_tree().change_scene_to_file(mainTownArea)
