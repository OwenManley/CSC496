extends Node2D

#there are no enemies in this copy of the central zone, this is the scene that will be used as a buffer between the
#player entering/leaving the town and entering/leaving the mines after they have already gone through the spooky version

var minesTheme1 = "res://Scenes/Levels/Mines/minesTheme1.tscn"
var mainTownArea = "res://Scenes/Levels/OutsideAreas/mainTownArea.tscn"
var leaf_particle = preload("res://Scenes/Particles/leaf.tscn")

func _on_ready() -> void:
	$Player.set_position(Vector2(Globals.playerPositionX, Globals.playerPositionY))
	Globals.currentScene = "res://Scenes/Levels/OutsideAreas/mainCentralZone.tscn"
	$Player.stopMovingForABit()
	$Player.updateZone(2)
	$AnimationPlayer.play("fade in")
	$AudioStreamPlayer.play()
	$"Mine Entrance/CollisionShape2D".set_deferred("disabled", true)
	await get_tree().create_timer(2.0).timeout
	$"Mine Entrance/CollisionShape2D".set_deferred("disabled", false)

func _process(_delta: float) -> void:
	_handle_falling_leaves()

func _on_mine_entrance_body_entered(body: Node2D) -> void:
	#await get_tree().create_timer(5.0, true, false, true).timeout #makes a delay
	$AnimationPlayer.play("fade out")
	if(body.is_in_group("PlayerBorders") == false): #prevents the staticborder from counting as entering the ladder
		get_tree().change_scene_to_file(minesTheme1)

func _on_town_collision_area_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #prevents the staticborder from counting as entering the ladder
		$AnimationPlayer.play("fade out")
		Globals.playerPositionX = 1876
		Globals.playerPositionY = 1242
		get_tree().change_scene_to_file(mainTownArea)

func _handle_falling_leaves() -> void:
	if(randf() <= 0.065):
		var object = leaf_particle.instantiate()
		var pos = $Player.damage_numbers_origin.global_position
		object.position = Vector2(
			pos.x + randi_range(-DisplayServer.screen_get_size().x, DisplayServer.screen_get_size().x)/2,
			pos.y - (DisplayServer.screen_get_size().y/4)
			)
		#print(pos, "   ", object.position)
		add_child(object)
