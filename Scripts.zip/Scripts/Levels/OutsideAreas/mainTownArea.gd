extends Node2D

#this is the town area, where buildings will be unlocked over time and the player is slowed down across the bridge

var mainCentralZone = "res://Scenes/Levels/OutsideAreas/mainCentralZone.tscn"
var hospital = "res://Scenes/Levels/BuildingInteriors/hospital.tscn"
var alchemist = "res://Scenes/Levels/BuildingInteriors/alchemist.tscn"

func _on_ready() -> void:
	$Player.set_position(Vector2(Globals.playerPositionX, Globals.playerPositionY))
	Globals.currentScene = "res://Scenes/Levels/OutsideAreas/mainTownArea.tscn"
	Globals.hasPlayerVisitedMinesYet = true
	$Player.stopMovingForABit()
	$Player.updateZone(1) #no HUD instructions
	$AudioStreamPlayer2.play()

func _on_audio_stream_player_finished() -> void:
	$AudioStreamPlayer.play()

func _on_audio_stream_player_2_finished() -> void:
	$AudioStreamPlayer2.play()

func _on_area_2d_2_body_entered(body: Node2D) -> void: #bridge
	if(body.is_in_group("Player") == true):
		$Player.speed = 750 #this & the line below it do the exact same thing, which is reduce the speed while crossing the bridge
		#$Player.slowSpeedFunc()
		$AudioStreamPlayer2.stop()
		$AudioStreamPlayer.play()

func _on_area_2d_2_body_exited(body: Node2D) -> void: #bridge
	$Player.normalSpeedFunc()
	$AudioStreamPlayer.stop()
	$AudioStreamPlayer2.play()

func _on_area_2d_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #only if the player collides with this box will the scene change
		Globals.playerPositionX = 130
		Globals.playerPositionY = 81
		get_tree().change_scene_to_file(mainCentralZone)

func _on_hospital_entrance_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #only if the player collides with this box will the scene change
		Globals.playerPositionX = 169
		Globals.playerPositionY = 281
		get_tree().change_scene_to_file(hospital)

func _on_alcehmist_entrance_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #only if the player collides with this box will the scene change
		Globals.playerPositionX = 214
		Globals.playerPositionY = 238
		get_tree().change_scene_to_file(alchemist)
