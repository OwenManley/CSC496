extends Node2D

var leaf_particle = preload("res://Scenes/Particles/leaf.tscn")
var isControllerPluggedIn : bool = false

func _on_ready() -> void:
	Globals.currentScene = "res://Scenes/Levels/OutsideAreas/Tutorial.tscn"
	$Spawner.execute()
	$Player.updateZone(1)
	$CutsceneHandler.tutorial()

func _process(_delta: float) -> void:
	_handle_falling_leaves()
	var connected_joysticks = Input.get_connected_joypads()
	if ((connected_joysticks.size() > 0) && !isControllerPluggedIn):
		isControllerPluggedIn = true
	if((connected_joysticks.size() == 0) && isControllerPluggedIn):
		isControllerPluggedIn = false
	$"TileMap Layers/Controller Signs".visible = isControllerPluggedIn
		#$"TileMap Layers/Collidable Props".set_cell(Vector2i(90, 22), 4, Vector2i(2, 4))
		
		#$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(0,32), 4, Vector2i(15,0))
		#$"TileMap Layers/Collidable Props and Environment Background".set_cell(Vector2i(1,32), 4, Vector2i(16,0))
		#$"TileMap Layers/Collidable Props and Environment Background".erase_cell(Vector2i(8,-48))
		#$"TileMap Layers/Collidable Props and Environment Background".erase_cell(Vector2i(8,-49))
		#$"TileMap Layers/Collidable Props and Environment Background".erase_cell(Vector2i(8,-50))
	#elif $"Area2D-Up/Node-Right".visible == true && !isControllerPluggedIn && $"Area2D-Up/Node-Up".visible == false:
		#$"Area2D-Up/Node-Right/RightKeyboard".texture = load($"Area2D-Up/Node-Right/RightKeyboard".texture.resource_path.replace("_controller.png", "_keyboard.png"))

func _handle_falling_leaves() -> void:
	if(randf() <= 0.065):
		var object = leaf_particle.instantiate()
		var pos = $Player.damage_numbers_origin.global_position
		object.position = Vector2(
			pos.x + randi_range(-DisplayServer.screen_get_size().x, DisplayServer.screen_get_size().x)/2,
			pos.y - (DisplayServer.screen_get_size().y/4)
			)
		#print(pos, "   ", object.position)
		object.set_meta("wind_speed", Globals.windSpeed)
		add_child(object)
		

func _on_area_2d_up_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"Area2D-Up/Node-Right".visible = false
		$"Area2D-Up/Node-Up".visible = true
	if isControllerPluggedIn:
		$"Area2D-Up/Node-Up/UpKeyboard".scale.x = 1
		$"Area2D-Up/Node-Up/UpKeyboard".scale.y = 1
		$"Area2D-Up/Node-Up/UpKeyboard".texture = load($"Area2D-Up/Node-Up/UpKeyboard".texture.resource_path.replace("_keyboard.png", "_controller.png"))

func _on_area_2d_pause_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"Area2D-Up/Node-Up".visible = false
		$"Area2D-Pause/Node-Pause".visible = true
	if isControllerPluggedIn:
		$"Area2D-Pause/Node-Pause/PauseKeyboard".texture = load($"Area2D-Pause/Node-Pause/PauseKeyboard".texture.resource_path.replace("_keyboard.png", "_controller.png"))

func _on_area_2d_inventory_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"Area2D-Pause/Node-Pause".visible = false
		$"Area2D-Inventory/Node-Inventory".visible = true
	if isControllerPluggedIn:
		$"Area2D-Inventory/Node-Inventory/InventoryKeyboard".texture = load($"Area2D-Inventory/Node-Inventory/InventoryKeyboard".texture.resource_path.replace("_keyboard.png", "_controller.png"))

func _on_area_2d_down_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"Area2D-Inventory/Node-Inventory".visible = false
		$"Area2D-Down/Node-Down".visible = true
	if isControllerPluggedIn:
		$"Area2D-Down/Node-Down/DownKeyboard".scale.x = 1
		$"Area2D-Down/Node-Down/DownKeyboard".scale.y = 1
		$"Area2D-Down/Node-Down/DownKeyboard".texture = load($"Area2D-Down/Node-Down/DownKeyboard".texture.resource_path.replace("_keyboard.png", "_controller.png"))

func _on_area_2d_left_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"Area2D-Down/Node-Down".visible = false
		$"Area2D-Left/Node-Left".visible = true
	if isControllerPluggedIn:
		$"Area2D-Left/Node-Left/LeftKeyboard".scale.x = 1
		$"Area2D-Left/Node-Left/LeftKeyboard".scale.y = 1
		$"Area2D-Left/Node-Left/LeftKeyboard".texture = load($"Area2D-Left/Node-Left/LeftKeyboard".texture.resource_path.replace("_keyboard.png", "_controller.png"))

func _on_area_2d_attack_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"Area2D-Left/Node-Left".visible = false
		$"Area2D-Attack/Node-Attack".visible = true
		$AnimationPlayer.play("attack")
	if isControllerPluggedIn:
		$"Area2D-Attack/Node-Attack/Mousey".offset.x = 10
		$"Area2D-Attack/Node-Attack/Mousey".hframes = 1
		$"Area2D-Attack/Node-Attack/Mousey".frame = 0
		$"Area2D-Attack/Node-Attack/Mousey".texture = load("res://Assets/Tutorial/attack_controller.png")

func _on_area_2d_mine_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		$"Area2D-Attack/Node-Attack".visible = false
		$"Area2D-Mine/Node-Mine".visible = true
		$AnimationPlayer.play("mine")
	if isControllerPluggedIn:
		$"Area2D-Mine/Node-Mine/Mousey".offset.x = 5
		$"Area2D-Mine/Node-Mine/Mousey".hframes = 1
		$"Area2D-Mine/Node-Mine/Mousey".frame = 0
		$"Area2D-Mine/Node-Mine/Mousey".texture = load("res://Assets/Tutorial/mine_controller.png")

func _on_area_2d_leave_body_entered(body: Node2D) -> void:
	#next scene collision box
	if(body.is_in_group("Player") == true):
		Globals.storyProgressIntroduction = 1
		Globals.playerPositionX = -1102
		Globals.playerPositionY = 972
		Globals.previousScene = Globals.currentScene
		get_tree().change_scene_to_file(Globals.mapTown)
