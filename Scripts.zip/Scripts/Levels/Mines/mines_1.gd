extends Node2D

#116, 99
#2993,98
#5918, 74
#9352, 20
#10817, -236
#14005, -558
#17708, -81
#19375, 1299
#22044, 860
#24948, -207
var floors = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] #number of floors in that theme - 1 bc it starts at 0
var xCoords = [166, 2993, 5918, 9352, 10817, 14005, 17708, 19375, 22044, 24948] #x coords of where to teleport player
var yCoords = [99, 98, 74, 20, -236, -558, -81, 1299, 860, -207] #y coords of where to teleport player to
var levels : int = floors.size() #number of floors travelled before next theme
var levelLabelNumber : int = 0 #what should the levelLabel start at

func _on_ready():
	$HUD.update_level(levelLabelNumber)
	$BlackBackground.visible = true
	$AnimationPlayer.play("fade in")
	print("yes")
	$CaveSounds.play()
	#disbaleExit() #this line NEEDS to be turned on once we decide where we want exit ladders

func disbaleExit():
	if(levels <= 0): #to make it so that once you have entered enough floors, you get sent to the final boos floor
		get_tree().change_scene_to_file("res://Scenes/Levels/the_mines2.tscn")
	else:
		#print("levels is: " + str(levels))
		#print("exit disbaled")
		$ExitLadderr.process_mode = Node.PROCESS_MODE_DISABLED
		await get_tree().create_timer(2.5).timeout
		$ExitLadderr.process_mode = Node.PROCESS_MODE_INHERIT
		#print("exit enable")

func randomCoords():
	var inty : int = randi() % floors.size() #levels 
	$AnimationPlayer.play("fade out")
	$Player.set_position(Vector2(xCoords[inty], yCoords[inty]))
	removey(inty)
	$AnimationPlayer.play("fade in")

func removey(inty):
	levels -= 1
	#print("after removey, levels is: " + str(levels))
	levelLabelNumber +=1
	$HUD.update_level(levelLabelNumber)
	#print("levels is: " + str(levels))
	xCoords.remove_at(inty)
	yCoords.remove_at(inty)
	floors.remove_at(inty)

func _on_exit_ladderr_body_entered(body: Node2D) -> void: #leave mines
	if(body.is_in_group("Player") == true): #prevents the staticborder from counting as entering the ladder
		$AnimationPlayer.play("fade out")
		await get_tree().create_timer(.5).timeout
		get_tree().change_scene_to_file("res://Scenes/Levels/MainAreaReturnReturnReturn.tscn")

func _on_down_ladder_body_entered(body: Node2D) -> void: #go to next floor
	if(body.is_in_group("Player") == true):
		#var inty = randomCoords()
		randomCoords()
		#$AnimationPlayer.play("fade out")
		#$Player.set_position(Vector2(xCoords[inty], yCoords[inty]))
		#removey(inty)
		#$AnimationPlayer.play("fade in")
		disbaleExit()
