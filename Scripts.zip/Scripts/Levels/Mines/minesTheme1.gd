extends Node2D

#this is where the player can go down as many floors as they would like



#116, 99
#2993,98
#5918, 74
#9352, 20
#10817, -236
#14005, -558
#17708, -81
#19375, 1299
#22044, 860
#24948, -207
var floors = [0, 1, 2, 3, 4, 5, 6, 7, 8, 9] #number of floors in that theme - 1 bc it starts at 0
var xCoords = [166, 2993, 5918, 9352, 10817, 14005, 17708, 19375, 22044, 24948] #x coords of where to teleport player
var yCoords = [99, 98, 74, 20, -236, -558, -81, 1299, 860, -207] #y coords of where to teleport player to
var levels : int = floors.size() #number of floors travelled before next theme
var levelLabelNumber : int = 0 #what should the levelLabel start at
var mainCentralZone = "res://Scenes/Levels/OutsideAreas/mainCentralZone.tscn"
var minesTheme2 = "res://Scenes/Levels/Mines/minesTheme2.tscn"
var spookyCentralZone = "res://Scenes/Levels/OutsideAreas/spookyCentralZone.tscn"
var MountHaven = "res://Scenes/Levels/OutsideAreas/Mount_Haven.tscn"

func _on_ready():
	$Player.stopMovingForABit()
	Globals.currentScene = "res://Scenes/Levels/Mines/minesTheme1.tscn"
	#updateZone(3) turns on the level counter in the top right
	$Player.updateZone(3)
	#print("levelLabelNumber of mines1 is: " + str(levelLabelNumber))
	#$HUD.turn_on_mining()
	$Player.updateMineDepth(levelLabelNumber)
	$HUD.update_level(levelLabelNumber)
	$AnimationPlayer.play("fade in")
	$CaveSounds.play()
	disbaleExit()

func _process(delta: float) -> void:
	pass
	
func disbaleExit():
	if !Globals.hasPlayerVisitedMinesYet:
		if(levelLabelNumber == 4):
			#$Player/Dialogue.displayDialogue(9, 10, 2)
			$Player/"Player Hud"/Dialogue.displayDialogue(
				["I should leave, nobody's down here."],["johnny"],["serious"], 0)

			$ExitLadders.process_mode = Node.PROCESS_MODE_DISABLED
			await get_tree().create_timer(2.5).timeout
			$ExitLadders.process_mode = Node.PROCESS_MODE_INHERIT
			print("exit enabled")
		elif(levelLabelNumber == 5): #kicks the player out of the mines if they try to go down more than 4 floors
			print("yes")
			Globals.playerPositionX = 2682
			Globals.playerPositionY = 534
			Globals.previousScene = Globals.currentScene
			get_tree().change_scene_to_file(MountHaven)
		else:
			#print("levels is: " + str(levels))
			print("exit disbaled")
			$ExitLadders.process_mode = Node.PROCESS_MODE_DISABLED
			await get_tree().create_timer(2.5).timeout
			$ExitLadders.process_mode = Node.PROCESS_MODE_INHERIT
			print("exit enable")
	else: #player has visited mines before and gone back to the town, making Globals.hasPlayerVisitedMinesYet = true
		if(levels <= 0): #to make it so that once you have entered enough floors, you get sent to the final boos floor
			Globals.previousScene = Globals.currentScene
			get_tree().change_scene_to_file(minesTheme2)
		else:
			#print("levels is: " + str(levels))
			#print("exit disbaled")
			$ExitLadders.process_mode = Node.PROCESS_MODE_DISABLED
			await get_tree().create_timer(2.5).timeout
			$ExitLadders.process_mode = Node.PROCESS_MODE_INHERIT
			#print("exit enable")

func randomCoords():
	var inty : int = randi() % floors.size() #levels 
	#print("inty is:" + str(inty))
	#print(xCoords[inty])
	#print(yCoords[inty])
	#print("-----")
	#print(xCoords)
	#print(yCoords)
	#print(floors)
	#print("------------------")
	
	#makes it so that spawners spawn before the player is tp'd to that floor instead of all at once
	match floors[inty]:
		0:
			$Spawner.execute()
		1:
			$Spawner2.execute()
		2:
			$Spawner3.execute()
		3:
			$Spawner4.execute()
		4:
			$Spawner5.execute()
		5:
			$Spawner6.execute()
		6:
			$Spawner7.execute()
		7:
			$Spawner8.execute()
		8:
			$Spawner9.execute()
		9:
			$Spawner10.execute()
	$AnimationPlayer.play("fade out")
	$Player.set_position(Vector2(xCoords[inty], yCoords[inty]))
	$Player.stopMovingForABit()
	removey(inty)
	$AnimationPlayer.play("fade in")

func removey(inty):
	levels -= 1
	#print("after removey, levels is: " + str(levels))
	levelLabelNumber +=1
	$Player.updateMineDepth(levelLabelNumber)
	$HUD.update_level(levelLabelNumber)
	#print("levels is: " + str(levels))
	xCoords.remove_at(inty)
	yCoords.remove_at(inty)
	floors.remove_at(inty)

func _on_exit_ladders_body_entered(body: Node2D) -> void:
	#if !Globals.hasPlayerVisitedMinesYet:
		#if(body.is_in_group("Player") == true):
			#$AnimationPlayer.play("fade out")
			#await get_tree().create_timer(.5).timeout
			#Globals.playerPositionX = 955
			#Globals.playerPositionY = 550
			#Globals.previousScene = Globals.currentScene
			#get_tree().change_scene_to_file(MountHaven)
	#else:
		if(body.is_in_group("Player") == true): #prevents the staticborder from counting as entering the ladder
			$AnimationPlayer.play("fade out")
			await get_tree().create_timer(.5).timeout
			Globals.playerPositionX = 2682
			Globals.playerPositionY = 534
			Globals.previousScene = Globals.currentScene
			get_tree().change_scene_to_file(MountHaven)

func _on_down_ladders_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		randomCoords()
		disbaleExit()

"""
#func _unhandled_input(event: InputEvent) -> void:
	#if event is InputEventKey: #once the exit is enabled again, can press E anywhere and yeah
		#if event.pressed and event.keycode == KEY_E and $ExitLadderr.process_mode == Node.PROCESS_MODE_INHERIT:
			#$AnimationPlayer.play("fade out")
			#await get_tree().create_timer(.5).timeout
			#get_tree().change_scene_to_file("res://Scenes/Levels/MainAreaReturn.tscn")
	#if event is InputEventKey: #pauses but won't unpause
		#if event.pressed and event.keycode == KEY_ESCAPE and get_tree().paused == false:
			#get_tree().paused = true
		#elif event.pressed and event.keycode == KEY_ESCAPE and get_tree().paused == true:
			#get_tree().paused = false
			
func _on_down_ladder_11_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		#var inty = randomCoords()
		randomCoords()
		#$AnimationPlayer.play("fade out")
		#$Player.set_position(Vector2(xCoords[inty], yCoords[inty]))
		#removey(inty)
		#$AnimationPlayer.play("fade in")
		disbaleExit()
"""
