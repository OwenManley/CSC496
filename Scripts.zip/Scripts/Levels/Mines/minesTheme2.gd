extends Node2D

#73, 3
#2139, 315
#4738, 482
#7017, 686
#9420, 797

var floors = [0, 1, 2, 3]  #number of floors in that theme - 1 bc it starts at 0
var xCoords = [2139, 4738, 7017, 9420] #x coords of where to teleport player
var yCoords = [315, 482, 686, 797] #y coords of where to teleport player to
var levels : int = floors.size() #number of floors travelled before next theme
var levelLabelNumber : int = 10 #what should the levelLabel start at
var mainCentralZone = "res://Scenes/Levels/OutsideAreas/Mount_Haven.tscn"


func _on_ready():
	$Player.stopMovingForABit()
	Globals.currentScene = "res://Scenes/Levels/Mines/minesTheme2.tscn"
	#updateZone(3) turns on the level counter in the top right
	$Player.updateZone(3)
	#print("levelLabelNumber is: " + str(levelLabelNumber))
	#$HUD.turn_on_mining()
	#print("turned on mining")
	$HUD.update_level(levelLabelNumber)
	$"TileMap Layers/BlackBackground".visible = true
	$AnimationPlayer.play("fade in")
	$CaveSounds.play()
	disbaleExit()

func disbaleExit():
	if(levels <= 0): #to make it so that once you have entered enough floors, you get sent to the final boos floor
		print("levels = o")
		levels = 0
		get_tree().change_scene_to_file("res://Scenes/Levels/the_mines2.tscn") #this will be like mines3, NOT mines2
	else:
		print("levels is: " + str(levels))
		#print("exit disbaled")
		$ExitLadders.process_mode = Node.PROCESS_MODE_DISABLED
		await get_tree().create_timer(2.5).timeout
		$ExitLadders.process_mode = Node.PROCESS_MODE_INHERIT
		#print("exit enable")

func randomCoords():
	var inty : int = randi() % floors.size() #levels 
	$AnimationPlayer.play("fade out")
	$Player.set_position(Vector2(xCoords[inty], yCoords[inty]))
	$Player.stopMovingForABit()
	removey(inty)
	$AnimationPlayer.play("fade in")

func removey(inty):
	levels -= 1
	print("after removey, levels is: " + str(levels))
	levelLabelNumber +=1
	$HUD.update_level(levelLabelNumber)
	#print("levels is: " + str(levels))
	xCoords.remove_at(inty)
	yCoords.remove_at(inty)
	floors.remove_at(inty)

func _on_exit_ladders_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true): #prevents the staticborder from counting as entering the ladder
		$AnimationPlayer.play("fade out")
		await get_tree().create_timer(.5).timeout
		Globals.playerPositionX = 955
		Globals.playerPositionY = 550
		get_tree().change_scene_to_file(mainCentralZone)

func _on_down_ladders_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		randomCoords()
		disbaleExit()
