extends Node2D

var leaf_particle = preload("res://Scenes/Particles/leaf.tscn")
var otherTilemap: Node2D
var length: int = 185 *16
var sinLength: float = 0.0
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	otherTilemap = $"TileMap Layers".duplicate()
	call_deferred("add_child", otherTilemap)
	otherTilemap.position.x = length
	
	scale *= 2.5
	position.y = -250


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	_handle_falling_leaves()
	$"TileMap Layers".position.x -= 2
	otherTilemap.position.x -= 2
	if $"TileMap Layers".position.x <= -length:
		$"TileMap Layers".position.x = length
	if otherTilemap.position.x <= -length:
		otherTilemap.position.x = length
	
	sinLength = wrap(sinLength+0.02, 0, 180)
	position.y = -270 + sin(sinLength)*20
	$Johnny.position.x = 120 + sin(sinLength-20)*20
	$James.position.x = 72 + sin(sinLength)*20
	$Johnny.position.y = 304 + sin(sinLength/2-20)*8
	$James.position.y = 304 + sin(sinLength*2)*8

func _handle_falling_leaves() -> void:
	if(randf() <= 0.065):
		var object = leaf_particle.instantiate()
		var pos = $Marker2D.global_position
		object.position = Vector2(
			pos.x + randi_range(-DisplayServer.screen_get_size().x, DisplayServer.screen_get_size().x)/2,
			pos.y - (DisplayServer.screen_get_size().y/4)
			)
		#print(pos, "   ", object.position)
		object.set_meta("wind_speed", -randf()*0.5-0.5)
		add_child(object)
