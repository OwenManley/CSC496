extends Node2D

var leaf_particle = preload("res://Scenes/Particles/leaf.tscn")
# Called when the node enters the scene tree for the first time.
func _ready() -> void:
	pass # Replace with function body.


# Called every frame. 'delta' is the elapsed time since the previous frame.
func _process(delta: float) -> void:
	_handle_falling_leaves()
	
func _handle_falling_leaves() -> void:
	if(randf() <= 0.065):
		var object = leaf_particle.instantiate()
		var pos = $Marker2D.global_position
		object.position = Vector2(
			pos.x + randi_range(-DisplayServer.screen_get_size().x, DisplayServer.screen_get_size().x)/2,
			pos.y - (DisplayServer.screen_get_size().y/4)
			)
		#print(pos, "   ", object.position)
		object.set_meta("wind_speed", randf()+1.0)
		add_child(object)
