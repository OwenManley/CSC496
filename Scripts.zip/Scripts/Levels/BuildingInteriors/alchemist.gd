extends Node2D

#alchemist apothecary scene

var mainTownArea = "res://Scenes/Levels/OutsideAreas/firstTownArea.tscn"

func _on_ready() -> void:
	$Player.set_position(Vector2(Globals.playerPositionX, Globals.playerPositionY))
	Globals.currentScene = "res://Scenes/Levels/BuildingInteriors/alchemist.tscn"

func _on_exit_box_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		Globals.playerPositionX = 57
		Globals.playerPositionY = 152
		get_tree().change_scene_to_file(mainTownArea)
