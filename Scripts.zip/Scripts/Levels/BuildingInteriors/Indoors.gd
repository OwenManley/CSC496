extends Node2D

@onready var houseLocationsInside : Dictionary = { # IMSIDE
	Globals.Houses.NONE : $SpawnLocations/Hospital.global_position, # Default to hospital. # Spaced by 568
	Globals.Houses.HOSPITAL : $SpawnLocations/Hospital.global_position, 
	Globals.Houses.BLACKSMITH : $SpawnLocations/Smith.global_position,
	Globals.Houses.ALCHEMIST : $SpawnLocations/Alchemist.global_position, 
	Globals.Houses.WIZARD : $SpawnLocations/Wizard.global_position,
}

func _on_ready() -> void:
	if Globals.lastKnownHouse == 0:
		Globals.lastKnownHouse = Globals.Houses.HOSPITAL
	
	$Player.set_position(houseLocationsInside.get(Globals.lastKnownHouse))
	Globals.currentScene = Globals.mapIndoors
	
	match Globals.lastKnownHouse:
		Globals.Houses.HOSPITAL:
			$Cameras/Hospital.enabled = true
			$Player/Camera2D.enabled = false
		Globals.Houses.BLACKSMITH:
			$Cameras/Smith.enabled = true
			$Player/Camera2D.enabled = false
		Globals.Houses.ALCHEMIST:
			$Cameras/Alchemist.enabled = true
			$Player/Camera2D.enabled = false
		Globals.Houses.WIZARD:
			$Cameras/Wizard.enabled = true
			$Player/Camera2D.enabled = false

func _process(delta: float) -> void:
	$Cameras/Wizard.global_position.y = clamp($Player.global_position.y, -424, 376)
	

func _on_exit_door_body_entered(body: Node2D) -> void:
	if(body.is_in_group("Player") == true):
		Globals.previousScene = Globals.currentScene
		get_tree().change_scene_to_file(Globals.mapTown)
