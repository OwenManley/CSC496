extends Node

signal cutsceneBegin
signal cutsceneEnd

@onready var player: Player = $"../Player"
var currentDirection: String = "none"
var isRunning: bool = false
var hideHud: bool = false

####################################################################################################
func _ready() -> void:
	pass # Replace with function body.

func _process(delta: float) -> void:
	if !currentDirection.begins_with("no"):
		player.moveInDirection(delta, currentDirection, isRunning)
	
	if hideHud:
		if player.player_hud.offset.y > -10_000:
			player.player_hud.offset.y -= 10
	elif player.player_hud.offset.y < 0: 
		player.player_hud.offset.y *= 0.8

####################################################################################################

func startACutscene(instaHide: bool) -> void:
	cutsceneBegin.emit()
	player.isControllable = false
	if instaHide:
		player.player_hud.offset.y = -10_000
	hideHud = true

func endACutscene() -> void:
	currentDirection = "none"
	await get_tree().create_timer(0.1).timeout
	player.isControllable = true
	#player.player_hud.visible = true
	hideHud = false
	cutsceneEnd.emit()
	await get_tree().create_timer(0.5).timeout
	

func makeDialogue(dialogueText, characters, faces, waitTime: float) -> void:
	#player.player_hud.visible = true
	hideHud = false
	player.player_hud.displayDialogue(dialogueText, characters, faces, waitTime)
	await get_tree().create_timer(0.01).timeout
	player.isControllable = false
	hideHud = true

####################################################################################################

func tutorial() -> void:
	startACutscene(true)
	currentDirection = "right"
	isRunning = true
	await get_tree().create_timer(1.2).timeout
	currentDirection = "up right"
	isRunning = false
	await get_tree().create_timer(0.4).timeout
	currentDirection = "down"
	isRunning = false
	await get_tree().create_timer(0.1).timeout
	currentDirection = "none"
	makeDialogue(["Ah! I think I finally made it!", "Just a bit further to go.", "Ironhaven, \npopulation - 1"],
	["johnny", "johnny", "sign dark"],["serious", "thinking", "sign dark"], 0)
	await get_tree().create_timer(0.5).timeout
	currentDirection = "right down"
	await get_tree().create_timer(0.4).timeout
	endACutscene()
	
func townFirst() -> void:
	startACutscene(true)
	currentDirection = "right"
	isRunning = false
	await get_tree().create_timer(1.5).timeout
	currentDirection = "none"
	await get_tree().create_timer(0.2).timeout
	makeDialogue(["Ah, Ironhaven.", "The town of my youth."],
	["johnny", "johnny"],["serious", "happy"], 0)
	isRunning = true
	await get_tree().create_timer(0.4).timeout
	currentDirection = "right"
	await get_tree().create_timer(1.4).timeout
	currentDirection = "up right"
	await get_tree().create_timer(2.1).timeout
	currentDirection = "right"
	await get_tree().create_timer(0.2).timeout
	isRunning = false
	currentDirection = "none"
	player.animation.play("Idle " + player.animationTypes[player.currentMainhandItem])
	await get_tree().create_timer(0.2).timeout
	#mkae it so that it checks if a controller is plugged in to display dif. stuff
	#if()
	makeDialogue(["Welcome To\nIronhaven!", "(Press \'E\'\nto interact with\nthese signs.)"],
	["sign", "sign"],["sign", "sign"], 0)
	isRunning = true
	currentDirection = "right"
	await get_tree().create_timer(0.6).timeout
	currentDirection = "up"
	await get_tree().create_timer(1.0).timeout
	$"../TileMap Layers/Collidable Props".set_cell(Vector2i(-1,33), 0, Vector2i(16,14))
	$"../TileMap Layers/Collidable Props".set_cell(Vector2i(-2,33), 0, Vector2i(15,14))
	$"../TileMap Layers/Collidable Props".set_cell(Vector2i(-3,33), 0, Vector2i(14,14))
	endACutscene()

func townFirstJames() -> void:
	startACutscene(true)
	player.position = Vector2(103*16,60*16)
	currentDirection = "left"
	isRunning = false
	await get_tree().create_timer(1.5).timeout
	currentDirection = "up left"
	await get_tree().create_timer(0.2).timeout
	await get_tree().create_timer(0.4).timeout
	currentDirection = "left"
	await get_tree().create_timer(1.4).timeout
	currentDirection = "up left"
	await get_tree().create_timer(0.2).timeout
	currentDirection = "left"
	await get_tree().create_timer(0.5).timeout
	currentDirection = "none"
	player.animation.play("Idle " + player.animationTypes[player.currentMainhandItem])
	await get_tree().create_timer(0.2).timeout
	makeDialogue(["What happened?\nWhere are our friends?", "Oh, tis' a terrible tale."],
	["johnny", "james"],["serious", "serious"], 0)
	currentDirection = "right"
	await get_tree().create_timer(0.2).timeout
	currentDirection = "none"
	await get_tree().create_timer(0.2).timeout
	makeDialogue(["Something happened deep in the mines...", "...and now there are terrible creatures that roam within them.", "Tis' a terrible tale, indeed."],
	["james", "james", "johnny"],["serious", "serious", "thinking"], 0)
	await get_tree().create_timer(0.2).timeout
	currentDirection = "left"
	await get_tree().create_timer(1.2).timeout
	currentDirection = "up left"
	await get_tree().create_timer(1.6).timeout
	makeDialogue(["Hmm... But what could we do now?", "We must go back in and stop those monsters!", "But first, there is an old friend, up north.\nHe would love to see you."],
	["johnny", "james", "james"],["thinking", "serious", "thinking"], 0)
	#await get_tree().create_timer(1.6).timeout
	#player.player_hud.fadeScreen(0.25, Color.TRANSPARENT, Color.BLACK)
	endACutscene()
