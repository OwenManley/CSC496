extends CanvasLayer

func dark():
	print("darky")
	$AnimationPlayer.play("dark")
